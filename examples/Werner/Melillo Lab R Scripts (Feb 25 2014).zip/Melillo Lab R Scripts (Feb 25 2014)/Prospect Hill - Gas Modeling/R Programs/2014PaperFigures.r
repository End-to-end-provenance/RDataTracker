#Yearly Bar Graph
png("YearlyGraph.png", width=350, height=250)
par(mar=c(3,3,1,0.5),mgp=c(2.5,0.5,0))

setwd("C:/MBL_HF/Harvard Forest/Prospect Hill/Gas/Data Analysis/2014/2014 Paper")
Yearly<-read.csv("R Input Files/PHYearlyResults.csv")

YearlyData<-tapply(Yearly$Flux, list(Yearly$Treatment,Yearly$Year), sum)
by<-barplot(YearlyData, beside=T, ylim=c(0,1200), ylab="", names.arg=rep(" ",46), col=c("grey86","grey37"), axes=F)
axis(side=1, at=seq(from=2, to=68, by=3), labels = c(1991:2013), las=2, cex.axis=0.75, tck=-0.02)
axis(side=2, pos=0, las=1, cex.axis=0.75, tck=-0.02)
lines(x=c(0,70), y=c(0,0))
arrows(x0=c(by[1,],by[2,]), y0=Yearly$Flux-Yearly$Error, x1=c(by[1,],by[2,]), y1=Yearly$Flux+Yearly$Error, angle=90, code=3, length=0)
legend(x=60, y=1100, legend=c("Control","Heated"), cex=0.75, pch=22, pt.cex=1, pt.bg=c("grey86","grey37"), bty="n")
text(x=c(14,44,59), y=c(970, 545, 675), labels = "*", cex=1)
#points(x=c(14,44,59), y=c(970, 545, 675), pch=8, cex=0.5)
mtext(expression(Soil~CO[2]~Flux~(g~C~m^{-2}*~year^{-1})), side=2, line=1.5, cex=1)

dev.off("YearlyGraph.png")

#Rolling Window Graph
png("WindowGraph.png", width=350, height=250)
par(mar=c(3.5,4,1,0.3),mgp=c(2.5,0.5,0))

setwd("C:/MBL_HF/Harvard Forest/Prospect Hill/Gas/Data Analysis/2014/2014 Paper")
Window<-read.csv("R Input Files/PHWindowResults.csv")

bw<-barplot(Window$Delta, ylim=c(-50,210), space=0.8, axes=F)
arrows(x0=bw, y0=Window$Delta-Window$DeltaStderr, x1=bw, y1=Window$Delta+Window$DeltaStderr, angle=90, code=3, length=0)
lines(x=c(0,40.5), y=c(0,0))
lines(x=c(0,40.5), y=c(-50,-50))
axis(side=1, labels=Window$Year, at=bw, cex.axis=0.75, las=2, tck=-0.02)
axis(side=2, pos=0, las=1, cex.axis=0.75, tck=-0.02)
mtext(expression(Delta(Headed-Control)~Soil~CO[2]~Flux), side=2, line=2.5, cex=1)
mtext(expression((g~C~m^{-2}*~year^{-1})), side=2, line=1.5, cex=1)

dev.off("WindowGraph.png")

#NMIN Graph
png("NMINGraph.png", width=350, height=250)
par(mar=c(3.5,4,1,0.3),mgp=c(2.5,0.5,0))
library(plotrix)

setwd("C:/MBL_HF/Harvard Forest/Prospect Hill/Gas/Data Analysis/2014/2014 Paper")
NMIN<-read.csv("R Input Files/NMIN.csv")
NMINData<-tapply(NMIN$Min, list(NMIN$Treat,NMIN$Year), sum)

bn<-barplot(NMINData, beside=T, ylim=c(0,200),axes=F, col=c("grey86","grey37"), names.arg=rep(" ",11))
arrows(x0=c(bn[1,],bn[2,]), y0=NMIN$Min-NMIN$Err, x1=c(bn[1,],bn[2,]), y1=NMIN$Min+NMIN$Err, angle=90, code=3, length=0)
axis(side=1, at=seq(from=2, to=32, by=3), labels=NMIN$Year[1:11], cex.axis=0.75, las=2, tck=-0.02)
axis(side=2, pos=0, las=1, cex.axis=0.75, tck=-0.02)
abline(h=0)
axis.break(axis=1, breakpos=30.5, brw=0.018)
axis.break(axis=1, breakpos=24.5, brw=0.018)
legend(x=28, y=185, legend=c("Control","Heated"), cex=0.75, pch=22, pt.cex=1, pt.bg=c("grey86","grey37"), bty="n")
mtext(expression(Nitrogen~Mineralization), side=2, line=2.5, cex=1)
mtext(expression((kg~N~ha^{-1}*~year^{-1})), side=2, line=1.5, cex=1)

dev.off("NMINGraph.png")

#SOM Graph
png("SOMGraph.png", width=200, height=250)
par(mar=c(1,4,1,0.3),mgp=c(2.5,0.5,0))

setwd("C:/MBL_HF/Harvard Forest/Prospect Hill/Gas/Data Analysis/2014/2014 Paper")
DCsom<-382.8
DCerr<-37.60
Hsom<-239.8
Herr<-27.95

bs<-barplot(c(DCsom,Hsom), space=1, axes=F, ylim=c(-50,450), xlim=c(0.5,4.5))
abline(h=0)
text(1.5,-20, "Control")
text(3.5,-20, "Heated")
axis(side=2, las=1)
mtext(expression(Organic~Horizon~SOM~(kg~m^{-2})), side=2, line=2.5, cex=1)
arrows(x0=bs, y0=c(DCsom-DCerr,Hsom-Herr), x1=bs, y1=c(DCsom+DCerr,Hsom+Herr), angle=90, code=3, length=0)

dev.off("SOMGraph.png")
#This script modeles CO2 emissions at prospect hill as a function of soil temperature, deriving the paramters we will use to model yearly emissions.

#I reccomend setting the Prospect Hill folder to your working directory. This will make all your pathways much more managable. To do so, type the pathway to the Prospect Hill/Gas/Data Analysis folder into the command below and execute:

setwd("C:/MBL_HF/Harvard Forest/Prospect Hill/Gas/Data Analysis")

#Imports Gas Data. If you get an error message saying "NAs introduced by coercion", it could mean you have negative CO2 fluxes in the raw data file (you can't take the log of a negative number). The rest of the script will function fine with the NAs in there.
CO2<-read.csv("R Input Files/SWCO2Data.csv")
CO2$lnCO2<-log(CO2$CO2)

#Check to make sure the data frame was created correctly. Even though we are treating it as a factor, you want year to be considered as an interger for this script (this allows for greater than/less than comparisons). If CO2 or Temp were interperted as factors, you probably have missing data points or typos in the input file. If you have extra variables with names like "X", "X.1", etc. you probably have extra (blank) columns in your .csv file.
str(CO2)

#How many years of memory are you giving the soil in terms of parameter calculation? To calculate parameters from 3 years, this number should be 2 (ie. the year in question plus the two previous years).
memory <- 2

#Are there any years you want to exclude from calculations?
badyears<-c(1995)
CO2b<-CO2[,1:6]
CO2b$CO2<-ifelse(CO2b$Year %in% badyears,NA,CO2$CO2)
CO2b$Temp<-ifelse(CO2b$Year %in% badyears,NA,CO2$Temp)
CO2b$lnCO2<-ifelse(CO2b$Year %in% badyears,NA,CO2$lnCO2)

#Creates a matrix to recieve parameters
nyears<-length(levels(as.factor(CO2b$Year)))
titles<-list(levels(as.factor(CO2b$Year)),c("DC.Int","DC.Exp","DC.Rsq","H.Int","H.Exp","H.Rsq"))
parameters<-matrix(numeric(0),nyears,6,dimnames=titles)

#check to make sure the parameter matrix was set up correctly. It should be filled with NAs at this point.
parameters

#Creates a pdf file that will store plots of fit diagnostics for you to review afterwards. By default it will overwrite a file by the same name, so change the file name and/or pathway if you don't want this to happen.
pdf("R Output Files/Parameter_fit_diagnostics.pdf", width=10, 
    height=6, onefile=T)

#Parameter calculation loop. The entire loop {all lines enclosed by brackets} needs to be executed at the same time. 
for (i in 1:nyears) {

  #calculates window for loop iteration
  lastyear=1990+i
  firstyear=lastyear-memory
  
  #Evaluates heated plot parameters
  H.subset<-subset(CO2b,Year>=firstyear & Year<=lastyear & Treatment=="H")
  H.model<-lm(lnCO2 ~ Temp, data=H.subset)
  parameters[i,'H.Int']<-exp(H.model$coefficients[1])
  parameters[i,'H.Exp']<-H.model$coefficients[2]
  parameters[i,'H.Rsq']<-summary(H.model)$r.squared
  
  #Evaluates disturbance control plot parameters
  DC.subset<-subset(CO2b,Year>=firstyear & Year<=lastyear & Treatment=="DC")
  DC.model<-lm(lnCO2 ~ Temp, data=DC.subset)
  parameters[i,'DC.Int']<-exp(DC.model$coefficients[1])
  parameters[i,'DC.Exp']<-DC.model$coefficients[2]
  parameters[i,'DC.Rsq']<-summary(DC.model)$r.squared

  #Generates plots for output to the pdf file
  par(mfrow=c(1,2))
  plot(with(DC.subset, lnCO2~Temp), main = paste(lastyear, "Linear Models"), col = 4, pch = 20,
       xlab=expression (Temperature (degree*C)),
       ylab=expression(LnCO[2]~Flux ~(mgC ~ m^{-2}* hr^{-1}))
       )
  points(with(H.subset, lnCO2~Temp), col = 2, pch = 20)
  curve((DC.model$coefficients[2]*x + DC.model$coefficients[1]), add = T, col = 4)
  curve((H.model$coefficients[2]*x +H.model$coefficients[1]), add = T, col = 2)
  mtext(paste("DC r2=",round(summary(DC.model)$r.squared,3)), side=3, adj = 0)
  mtext(paste("H r2=",round(summary(H.model)$r.squared,3)), side=3, adj = 1)
  plot(with(DC.subset, CO2~Temp), main = paste(lastyear, "Parameters"), col = 4, pch = 20,
       xlab=expression (Temperature (degree*C)),
       ylab=expression(CO[2]~Flux ~(mgC ~ m^{-2}* hr^{-1}))
       )
  points(with(H.subset, CO2~Temp), col = 2, pch = 20)
  curve(exp(DC.model$coefficients[1])*exp(x*DC.model$coefficients[2]), add = T, col = 4)
  curve(exp(H.model$coefficients[1])*exp(x*H.model$coefficients[2]), add = T, col = 2)
  par(mfrow=c(2,4))
  plot(H.model, main = paste("Heated", lastyear))
  plot(DC.model, main = paste("DC", lastyear))
}

#Closes the pdf file, in the sense that further plots will be displayed rather than passed to the pdf. You still must close R Studio before you can open the file. Negative CO2 fluxes in the raw data file will produce the same error message here as they do when you initially calculate lnCO2. 
dev.off("Parameter_fit_diagnostics.pdf")

#Displays the filled parameter matrix.
parameters

#Creates a csv file of the parameters matrix. By default it will overwrite a file by the same name, so change the file name and/or pathway if you don't want this to happen.
write.csv(parameters, file = "R Output Files/Parameters.csv")
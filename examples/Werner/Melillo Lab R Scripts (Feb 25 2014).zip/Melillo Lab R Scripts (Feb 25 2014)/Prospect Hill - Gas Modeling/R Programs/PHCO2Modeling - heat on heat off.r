#This script takes the logger data and the output file from the PHParameters script and models daily, monthly and yearly CO2 emissions from the Prospect Hill warming site.

#I reccomend setting the Prospect Hill/Gas/Data Analysis folder to your working directory. This will make all your pathways much more managable:

setwd("C:/MBL_HF/Harvard Forest/Prospect Hill/Gas/Data Analysis/2014")

#This script relies on the chron package, so you will need to install it if you don't have it. If chron becomes unavaliable in the future, you will have to find an alternative to the month.day.year() function used to generate month levels from julian dates.

###Datafile Import and Merging------------------
#Imports raw data files. This needs to be updated every year to account for changes in datafile names.
#There are multiple files here because prior to 2010, excel files could have a maximum of ~32,000 rows of data in them. In Excel 2010, this limit was increased to slightly over one million, so it is unlikely that we will need to create a fifth file in the future.
Logger9197 <- read.csv("R Input Files/Logger9197.csv")
Logger9899 <- read.csv("R Input Files/Logger9899.csv")
Logger0006 <- read.csv("R Input Files/Logger0006.csv")
Logger0713 <- read.csv("R Input Files/Logger0713.csv")

#Check any datafile(s) you created or altered, even in seemingly trivial ways, to make sure it has the correct structure. If some of your columns were interperted as factors, you probably have typos or relics from excel (ie. #DIV/0!) in it. If you have exta variables at the end, you probably have blank columns in your csv file.
str(Logger9197)
str(Logger9899)
str(Logger0006)
str(Logger0713)

#Merges the raw logger data into a single dataframe. This will also need to be updated every year. 
Logger<-rbind(Logger9197,Logger9899,Logger0006,Logger0713)

#Removes any duplicate rows. There shouldn't be any, but if there are, this will get rid of them.
Logger<-unique(Logger)

#Calculates DC average and average delta.
Logger$DCave <- round(apply(as.matrix(Logger[, grep("D", names(Logger))]), 1, mean, na.rm = T),2)
Logger$Delta <- round(apply(as.matrix(Logger[, grep("H", names(Logger))]), 1,mean,na.rm=T, 2)-Logger$DCave, 2)

#Imports Wofsey and Fisher Tower data for gapfilling and merges with Logger Data.
Wofsy9199 <- read.csv("R Input Files/Wofsy9199.csv")
Wofsy0006 <- read.csv("R Input Files/Wofsy0006.csv")
Fisher <- read.csv("R Input Files/Fisher0713.csv")
Wofsy <- merge(Wofsy9199,Wofsy0006,all.x = T, all.y = T, sort = T)
Towers <- merge(Wofsy,Fisher,all.x=T,all.y=T,sort=T)
LoggerTowers <- merge(Logger,Towers,by=c("Year","Jday","Hour"),all.x=T, sort=T)

###Missing Data Modeling---------------------
#Calculates seperate models for the Wofsy and Fisher Towers. 
WofsyModel <- with(LoggerTowers, lm(DCave~WofsyTemp))
FisherModel <-with(LoggerTowers, lm(DCave~FisherTemp))

#Uses the appropriate model to generate the modeled temperatures
LoggerTowersW <- LoggerTowers[LoggerTowers[,"Year"]<2007,]
LoggerTowersW$ModeledTemp<-(WofsyModel$coefficients[2]*LoggerTowersW$WofsyTemp + WofsyModel$coefficients[1])
LoggerTowersF<- LoggerTowers[LoggerTowers[,"Year"]>2006,]
LoggerTowersF$ModeledTemp<-(FisherModel$coefficients[2]*LoggerTowersF$FisherTemp + FisherModel$coefficients[1])
LoggerTowers<-merge(LoggerTowersW,LoggerTowersF,all.y=T,all.x=T,sort=T)

#Keeps pre-gapfilling DC average, then fills in all missing temperatures with modeled temperatures.
LoggerGapfilled <- LoggerTowers[,c(1:3,22)]
LoggerGapfilled$H1 <- with(LoggerTowers, ifelse(is.na(H1),ModeledTemp,H1))
LoggerGapfilled$H6 <- with(LoggerTowers, ifelse(is.na(H6),ModeledTemp,H6))
LoggerGapfilled$H8 <- with(LoggerTowers, ifelse(is.na(H8),ModeledTemp,H8))
LoggerGapfilled$H12 <- with(LoggerTowers, ifelse(is.na(H12),ModeledTemp,H12))
LoggerGapfilled$H15 <- with(LoggerTowers, ifelse(is.na(H15),ModeledTemp,H15))
LoggerGapfilled$H16 <- with(LoggerTowers, ifelse(is.na(H16),ModeledTemp,H16))
LoggerGapfilled$D3 <- with(LoggerTowers, ifelse(is.na(D3),ModeledTemp,D3))
LoggerGapfilled$D5 <- with(LoggerTowers, ifelse(is.na(D5),ModeledTemp,D5))
LoggerGapfilled$D9 <- with(LoggerTowers, ifelse(is.na(D9),ModeledTemp,D9))
LoggerGapfilled$D10 <- with(LoggerTowers, ifelse(is.na(D10),ModeledTemp,D10))
LoggerGapfilled$D13 <- with(LoggerTowers, ifelse(is.na(D13),ModeledTemp,D13))
LoggerGapfilled$D17 <- with(LoggerTowers, ifelse(is.na(D17),ModeledTemp,D17))
LoggerGapfilled$Delta <- with(LoggerTowers, ifelse(is.na(Delta),0,Delta))

###Modeling Emissions from Temperatures--------------
#Imports the parameters matrix from the Parameter derivation script. If you have run the paramter script in this same R session and have not removed any objects from your workspace you can skip/comment out the first line.
parameters<-read.csv("R Output Files/Parameters_onoff.csv")
names(parameters)[1]<-"Year"

#Calculates CO2 emissions over the course of the experiment in g CO2/m2/hr.
CO2.g.m2.hr<-merge(LoggerGapfilled, parameters[,c(1:3,5,6,8,9)],sort=T)
CO2.g.m2.hr$H1CO2<-with(CO2.g.m2.hr,ifelse(Delta >= 4, (H.Int.on*exp(H1*H.Exp.on)/1000),
                                           (H.Int.off*exp(H1*H.Exp.off)/1000)))
CO2.g.m2.hr$H6CO2<-with(CO2.g.m2.hr,ifelse(Delta >= 4, (H.Int.on*exp(H6*H.Exp.on)/1000),
                                           (H.Int.off*exp(H6*H.Exp.off)/1000)))
CO2.g.m2.hr$H8CO2<-with(CO2.g.m2.hr,ifelse(Delta >= 4, (H.Int.on*exp(H8*H.Exp.on)/1000),
                                           (H.Int.off*exp(H8*H.Exp.off)/1000)))
CO2.g.m2.hr$H12CO2<-with(CO2.g.m2.hr,ifelse(Delta >= 4, (H.Int.on*exp(H12*H.Exp.on)/1000),
                                           (H.Int.off*exp(H12*H.Exp.off)/1000)))
CO2.g.m2.hr$H15CO2<-with(CO2.g.m2.hr,ifelse(Delta >= 4, (H.Int.on*exp(H15*H.Exp.on)/1000),
                                           (H.Int.off*exp(H15*H.Exp.off)/1000)))
CO2.g.m2.hr$H16CO2<-with(CO2.g.m2.hr,ifelse(Delta >= 4, (H.Int.on*exp(H16*H.Exp.on)/1000),
                                           (H.Int.off*exp(H16*H.Exp.off)/1000)))
CO2.g.m2.hr$H6CO2<-with(CO2.g.m2.hr,ifelse(Delta >= 4, (H.Int.on*exp(H6*H.Exp.on)/1000),
                                           (H.Int.off*exp(H6*H.Exp.off)/1000)))
CO2.g.m2.hr$D3CO2<-with(CO2.g.m2.hr,(DC.Int*exp(D3*DC.Exp)/1000))
CO2.g.m2.hr$D5CO2<-with(CO2.g.m2.hr,(DC.Int*exp(D5*DC.Exp)/1000))
CO2.g.m2.hr$D9CO2<-with(CO2.g.m2.hr,(DC.Int*exp(D9*DC.Exp)/1000))
CO2.g.m2.hr$D10CO2<-with(CO2.g.m2.hr,(DC.Int*exp(D10*DC.Exp)/1000))
CO2.g.m2.hr$D13CO2<-with(CO2.g.m2.hr,(DC.Int*exp(D13*DC.Exp)/1000))
CO2.g.m2.hr$D17CO2<-with(CO2.g.m2.hr,(DC.Int*exp(D17*DC.Exp)/1000))

write.csv(CO2.g.m2.hr, "R Output Files/HourlyCO2Fluxes.csv", row.names=F)

###Daily Fluxes----------
#Calculates CO2 emissions over the course of the experiment in g CO2/m2/day.
CO2.g.m2.day<-aggregate(CO2.g.m2.hr[,c("H1CO2","H6CO2","H8CO2","H12CO2","H15CO2","H16CO2","D3CO2","D5CO2","D9CO2","D10CO2","D13CO2","D17CO2")],CO2.g.m2.hr[,c("Jday","Year")], FUN=sum, na.rm=T)

#Uncomment the following line to get daily flux values
write.csv(CO2.g.m2.day,"R Output Files/DailyFluxes.csv", row.names=F)

###Monthly Fluxes--------------
#Calculates CO2 emissions over the course of the experiment in g CO2/m2/month.
library(chron)
CO2.g.m2.hr$month<-as.factor(month.day.year(CO2.g.m2.hr$Jday)$month)
CO2.g.m2.month<-aggregate(CO2.g.m2.hr[,c("H1CO2","H6CO2","H8CO2","H12CO2","H15CO2","H16CO2","D3CO2","D5CO2","D9CO2","D10CO2","D13CO2","D17CO2")],CO2.g.m2.hr[,c("month","Year")], FUN=sum, na.rm=T)

#Uncomment the following line to get monthly flux values
#write.csv(CO2.g.m2.month,"R Output Files/MonthlyFluxes.csv")

###Yearly Fluxes---------------------
#Calculates CO2 emissions over the course of the experiment in g CO2/m2/year. This seems like a pretty hackeyed coding trick, and there's probably a better way of summarizing multiple variables (CO2 for each plot) by a single factor (Year) than tricking aggregate() into thinking that Year is two seperate factors. But I haven't figured it out, so here it is.
CO2.g.m2.hr$Year2<-CO2.g.m2.hr$Year
CO2.g.m2.year<-aggregate(CO2.g.m2.hr[,c("H1CO2","H6CO2","H8CO2","H12CO2","H15CO2","H16CO2","D3CO2","D5CO2","D9CO2","D10CO2","D13CO2","D17CO2")],CO2.g.m2.hr[,c("Year","Year2")], FUN=sum, na.rm=T)
#Removes the extra year variable
CO2.g.m2.year<-CO2.g.m2.year[,-2]

#Writes a standard error function. You'd think the R base package would have one, but apparantly it doesn't.
stderr <- function(x) sd(x, na.rm=T)/sqrt(length(na.omit(x)))

#Calculates averages, standard errors, % increases, etc. for yearly fluxes.
CO2.g.m2.year$DCave<-apply(as.matrix(CO2.g.m2.year[,8:13]),1,mean)
CO2.g.m2.year$Have<-apply(as.matrix(CO2.g.m2.year[,2:7]),1,mean)
CO2.g.m2.year$Delta<-with(CO2.g.m2.year, Have-DCave)
CO2.g.m2.year$DCstdev<-apply(as.matrix(CO2.g.m2.year[,8:13]),1,sd)
CO2.g.m2.year$Hstdev<-apply(as.matrix(CO2.g.m2.year[,2:7]),1,sd)
CO2.g.m2.year$DCstderr<-apply(as.matrix(CO2.g.m2.year[,8:13]),1,stderr)
CO2.g.m2.year$Hstderr<-apply(as.matrix(CO2.g.m2.year[,2:7]),1,stderr)
CO2.g.m2.year$Deltastderr<-with(CO2.g.m2.year, sqrt(Hstderr^2 + DCstderr^2))
CO2.g.m2.year$PercentIncrease<-with(CO2.g.m2.year, (Have-DCave)/DCave)*100
CO2.g.m2.year$PctIncStdErr<-abs(with(CO2.g.m2.year, (sqrt((Hstdev/Have)^2+(DCstdev/DCave)^2)+((DCstdev/DCave)^2))*PercentIncrease))

#Uncomment the following line to get yearly flux values. From this point forward, it will be easier to use Excel than R.
write.csv(CO2.g.m2.year,"R Output Files/YearlyFluxes_131120.csv", row.names=F)

###Partial-Year Fluxes------------
###The following section is for when Jerry requests a midsummer update on data analysis. This allows you to compare the year so far to the comprable portion of every other year. Modify the following line for the months you want included in the analysis - for example, if it's August and you have data up through July, typing "month %in% c(1:7)" will have R discard all data not in months 1-7; the result will be the fluxes that accumulated between January and July from each year.
CO2.halfyear<-subset(CO2.g.m2.month, month %in% c(1:9))

CO2.halfyear$Year2<-CO2.halfyear$Year
CO2.g.m2.halfyear<-aggregate(CO2.halfyear[,c("H1CO2","H6CO2","H8CO2","H12CO2","H15CO2","H16CO2","D3CO2","D5CO2","D9CO2","D10CO2","D13CO2","D17CO2")],CO2.halfyear[,c("Year","Year2")], FUN=sum, na.rm=T)
#Removes the extra year variable
CO2.g.m2.halfyear<-CO2.g.m2.halfyear[,-2]

#Calculates averages, standard errors, % increases, etc. for yearly fluxes.
CO2.g.m2.halfyear$DCave<-apply(as.matrix(CO2.g.m2.halfyear[,8:13]),1,mean)
CO2.g.m2.halfyear$Have<-apply(as.matrix(CO2.g.m2.halfyear[,2:7]),1,mean)
CO2.g.m2.halfyear$Delta<-with(CO2.g.m2.halfyear, Have-DCave)
CO2.g.m2.halfyear$DCstdev<-apply(as.matrix(CO2.g.m2.halfyear[,8:13]),1,sd)
CO2.g.m2.halfyear$Hstdev<-apply(as.matrix(CO2.g.m2.halfyear[,2:7]),1,sd)
CO2.g.m2.halfyear$DCstderr<-apply(as.matrix(CO2.g.m2.halfyear[,8:13]),1,stderr)
CO2.g.m2.halfyear$Hstderr<-apply(as.matrix(CO2.g.m2.halfyear[,2:7]),1,stderr)
CO2.g.m2.halfyear$Deltastderr<-with(CO2.g.m2.halfyear, sqrt(Hstderr^2 + DCstderr^2))
CO2.g.m2.halfyear$PercentIncrease<-with(CO2.g.m2.halfyear, (Have-DCave)/DCave)*100
CO2.g.m2.halfyear$PctIncStdErr<-abs(with(CO2.g.m2.halfyear, (sqrt((Hstdev/Have)^2+(DCstdev/DCave)^2)+((DCstdev/DCave)^2))*PercentIncrease))

write.csv(CO2.g.m2.halfyear, "R Output Files/HalfYearFluxes.csv", row.names=F)

###Performance History Datafile--------------
#Calcualtes data to update the performance history tab in the results file.
DailyDeltas<-aggregate(Logger[,c("Delta")],CO2.g.m2.hr[,c("Jday","Year")], FUN=mean, na.rm=T)
names(DailyDeltas)[3]<-"Delta"
Performance<-reshape(DailyDeltas, timevar="Jday", v.names="Delta", direction="wide", idvar="Year")
PerformDays<-c(names(Performance[1]),names(Performance[186:366]),names(Performance[2:185]),names(Performance[367]))
PerformHist<-Performance[,PerformDays]

write.csv(PerformHist,"R Output Files/PerformanceHistory.csv", row.names=F)

###Harvard Forest Archives Datafile---------------
#Reformats this into the summary we submit to the Harvard Forest data archives.
#This section is not currently working.
LoggerAllYearsExp<-Logger
LoggerAllYearsExp$Month<-month.day.year(LoggerAllYearsExp$Jday)$month
LoggerAllYearsExp$Day<-month.day.year(LoggerAllYearsExp$Jday)$day
LoggerAllYearsDaily<-aggregate(LoggerAllYearsExp[,c("Month","Day","H1","H6","H8","H12","H15","H16","D3","D5","D9","D10","D13","D17","C2","C4","C7","C11","C14","C18","DCavg","Cavg","Havg","ShedTemp")],LoggerAllYears[,c("Jday","Year")], FUN=mean, na.rm=T)

#Use this to truncate the dataset by year. We are required to submit all data within three years, so we hold back the last two years of data in the submission.
PHArchivesSummary<-subset(LoggerAllYearsDaily, Year <= 2011)

write.csv(PHArchivesSummary, "R Output Files/PHArchivesSummary.csv", row.names=F)

###Statistical Testing------------------------
#Runs ANOVAs on year windows to determine if the heated plots are significantly different from the control plots for a given window.

#Transforms yearly CO2 flux dataframe into long format and drops columns unnecessairy for this analysis.
CO2.g.m2.year.long<-reshape(CO2.g.m2.year, varying=c("H1CO2","H6CO2","H8CO2","H12CO2","H15CO2","H16CO2","D3CO2","D5CO2","D9CO2","D10CO2","D13CO2","D17CO2"), v.names="CO2.year", timevar="Plot", times=c("H1","H6","H8","H12","H15","H16","D3","D5","D9","D10","D13","D17"), idvar = "Year", direction="long", drop=c("DCave","Have","Delta","DCstdev","Hstdev","DCstderr","Hstderr","Deltastderr","PercentIncrease","PctIncStdErr"))
CO2.g.m2.year.long$Treatment<-substr(CO2.g.m2.year.long$Plot,1,1)

#Adjust the window in the subset command, and then run an ANOVA on the data. Summary gives you your results, plot gives you indicatiors of assumption violations.
#CO2.g.m2.year.window<-subset(CO2.g.m2.year.long, Year %in% c(2011:2013))
CO2.g.m2.year.window<-subset(CO2.g.m2.year.long, Year==2007)

#Test for normality in both heated and control samples. Note that a balanced t-test is fairly robust against vioations of this assumption, so only severe violations are cause for concern. If one of these tests is severely violated, instead use the results of the wilcox.test (technically a Mann-Whitney-Wilcoxon test). Equal variances are not tested for because by default R uses Welch's correction for unequal variance in when running a t-test.
CO2.g.m2.year.window.H<-subset(CO2.g.m2.year.window, Treatment=="H")
shapiro.test(CO2.g.m2.year.window.H$CO2.year)

CO2.g.m2.year.window.D<-subset(CO2.g.m2.year.window, Treatment=="D")
shapiro.test(CO2.g.m2.year.window.D$CO2.year)

#If the reuslt of the t-test is near significant, run a bartlett's test to see if you can run the t-test without Welch's correction (which diminishes the power of the test). If the bartlett's test passes, you may include the argument "var.equal=T" in the t-test command to run the more powerful but also more sensitive to unequal variance version.
bartlett.test(CO2.g.m2.year.window$CO2.year, CO2.g.m2.year.window$Treatment)

t.test(CO2.year~Treatment, data=CO2.g.m2.year.window, var.equal=T)
wilcox.test(CO2.year~Treatment, data=CO2.g.m2.year.window)
#This script modeles CO2 emissions at prospect hill as a function of soil temperature, deriving the paramters we will use to model yearly emissions.

#I reccomend setting the Prospect Hill folder to your working directory. This will make all your pathways much more managable. If you are using R Studio, you can do this from the Session menu. Otherwise, enter the pathway to the Prospect Hill folder into the command below and execute:

setwd("C:/MBL_HF/Harvard Forest/Prospect Hill/Gas/Data Analysis/2014/")

#This script relies on the Hmisc package, so you'll need to install it if you don't already have it. If Hmisc becomes unavaliable in the future, you will need to find an alternative to the summarize() function used to calcualte DC average temperatures. NOTE: This was one of the first scripts I wrote; in hindsight, you could probably use aggregate() to the same effect without requiring a third-party package.

#Imports Gas Data and generates deltas for each sampling.
library(Hmisc)
CO2<-read.csv("R Input Files/SWCO2Data.csv")
CO2$lnCO2<-log(CO2$CO2)
CO2$Date<-with(CO2, paste(Year,Month,Day,Time))
DCavgs<-with(subset(CO2, Treatment=="DC"), summarize(Temp,Date,mean))
CO2$DCavg<-DCavgs[match(CO2$Date,DCavgs$Date),2]
CO2$Delta<-CO2$Temp-CO2$DCavg

#Check to make sure the data frame was created correctly. Even though we are treating it as a factor, you want year to be treated as an interger by this script (this allows for greater than/less than comparisons). If CO2 or Temp were interperted as factors, you probably have missing data points or typos in the input file. If you have extra variables with names like "X", "X.1", etc. you probably have extra (blank) columns in your .csv file.
str(CO2)

#Are there any years you want to exclude from calculations?
badyears<-c(1995)
CO2b<-CO2[,c(1:6,12)]
CO2b$CO2<-ifelse(CO2b$Year %in% badyears,NA,CO2$CO2)
CO2b$Temp<-ifelse(CO2b$Year %in% badyears,NA,CO2$Temp)
CO2b$lnCO2<-ifelse(CO2b$Year %in% badyears,NA,CO2$lnCO2)

#How many previous years of data do you want to include in the parameter calculations for a given year?
memory <- 3

#Creates a matrix to recieve parameters
nyears<-length(levels(as.factor(CO2b$Year)))
titles<-list(levels(as.factor(CO2b$Year)),c("DC.Int","DC.Exp","DC.Rsq","H.Int.on","H.Exp.on","H.Rsq.on","H.Int.off","H.Exp.off","H.Rsq.off"))
parameters<-matrix(numeric(0),nyears,9,dimnames=titles)

#check to make sure the parameter matrix was set up correctly. It should be filled with NAs at this point.
parameters

#Creates a pdf file that will store plots of fit diagnostics for you to review afterwards. By default it will overwrite a file by the same name, so change the file name and/or pathway if you don't want this to happen. Make sure to also update the name of the file in the dev.off() command after the paramter calculation loop.

pdf("R Output Files/Parameter_fit_diagnostics_onoff_reformatted.pdf", width=10, 
    height=9, onefile=T)

#Parameter calculation loop. The entire loop needs to be executed at the same time. 
for (i in 1:nyears) {

  #calculates window for loop iteration
  lastyear=1990+i
  firstyear=lastyear-memory
  
  #Evaluates heated plot (heat on) parameters
  H.on.subset<-subset(CO2b,Year>=firstyear & Year<=lastyear & Treatment=="H" & Delta >= 4)
  H.on.model<-lm(lnCO2 ~ Temp, data=H.on.subset)
  H.on.data<-data.frame(H.on.subset$Temp,H.on.subset$CO2)
  parameters[i,'H.Int.on']<-exp(H.on.model$coefficients[1])
  parameters[i,'H.Exp.on']<-H.on.model$coefficients[2]
  parameters[i,'H.Rsq.on']<-summary(H.on.model)$r.squared
  
  #Evaluates heated plot (heat off) parameters
  H.off.subset<-subset(CO2b,Year>=firstyear & Year<=lastyear & Treatment=="H" & Delta < 4)
  H.off.model<-lm(lnCO2 ~ Temp, data=H.off.subset)
  H.off.data<-data.frame(H.off.subset$Temp,H.off.subset$CO2)
  parameters[i,'H.Int.off']<-exp(H.off.model$coefficients[1])
  parameters[i,'H.Exp.off']<-H.off.model$coefficients[2]
  parameters[i,'H.Rsq.off']<-summary(H.off.model)$r.squared
  
  #Evaluates disturbance control plot parameters
  DC.subset<-subset(CO2b,Year>=firstyear & Year<=lastyear & Treatment=="DC")
  DC.model<-lm(lnCO2 ~ Temp, data=DC.subset)
  DC.data<-data.frame(DC.subset$Temp,DC.subset$lnCO2)
  parameters[i,'DC.Int']<-exp(DC.model$coefficients[1])
  parameters[i,'DC.Exp']<-DC.model$coefficients[2]
  parameters[i,'DC.Rsq']<-summary(DC.model)$r.squared

  #Generates plots for output to the pdf file
  par(mfrow=c(1,2), mai=c(4,1.5,1,0.25))
  plot(with(DC.subset, lnCO2~Temp), main = paste(lastyear, "Linear Models"), col = 4, pch = 20,
       xlab=expression (Temperature (degree*C)),
       ylab=expression(LnCO[2]~Flux ~(mgC ~ m^{-2}* hr^{-1}))
  )
  points(with(H.on.subset, lnCO2~Temp), col = 2, pch = 20)
  points(with(H.off.subset, lnCO2~Temp), col = "green", pch = 20)  
  curve((DC.model$coefficients[2]*x + DC.model$coefficients[1]), add = T, col = 4)
  curve((H.on.model$coefficients[2]*x +H.on.model$coefficients[1]), add = T, col = 2)
  curve((H.off.model$coefficients[2]*x +H.off.model$coefficients[1]), add = T, col = "green")
  mtext(paste("DC r2=",round(summary(DC.model)$r.squared,3)), side=1, adj = 0, line=4.5)
  mtext(paste("H (on) r2=",round(summary(H.on.model)$r.squared,3)), side=1, adj = 0, line=6)
  mtext(paste("H (off) r2=",round(summary(H.off.model)$r.squared,3)), side=1, adj = 0, line=7.5)
  plot(with(DC.subset, CO2~Temp), main = paste(lastyear, "Parameters"), col = 4, pch = 20,
       xlab=expression (Temperature (degree*C)),
       ylab=expression(CO[2]~Flux ~(mgC ~ m^{-2}* hr^{-1}))
  )
  points(with(H.on.subset, CO2~Temp), col = 2, pch = 20)
  points(with(H.off.subset, CO2~Temp), col = "green", pch = 20)
  curve(exp(DC.model$coefficients[1])*exp(x*DC.model$coefficients[2]), add = T, col = 4)
  curve(exp(H.on.model$coefficients[1])*exp(x*H.on.model$coefficients[2]), add = T, col = 2)
  curve(exp(H.off.model$coefficients[1])*exp(x*H.off.model$coefficients[2]), add = T, col = "green")
  #mtext(paste("DC =",round(exp(DC.model$coefficients[1]),2)), side=1, adj = 0, line=4.5)
  #mtext(paste(round(DC.model$coefficients[2],4),"t"), side=1, adj=0, line=4, cex=0.7, at=10)
  #mtext(paste("H (on) =",round(exp(H.on.model$coefficients[1]),2)), side=1, adj = 0, line=6)
  #mtext(paste(round(H.on.model$coefficients[2],4),"t"), side=1, adj=0, line=5.5, cex=0.7, at=12)
  #mtext(paste("H (off) =",round(exp(H.off.model$coefficients[1]),2)), side=1, adj = 0, line=7.5)
  #mtext(paste(round(H.off.model$coefficients[2],4),"t"), side=1, adj=0, line=7, cex=0.7, at=12)
  par(mfrow=c(3,4), mai=c(0.5,0.65,0.75,0.25))
  plot(H.on.model, main = paste("Heated - heat on", lastyear))
  plot(H.off.model, main = paste("Heated - heat off", lastyear))
  plot(DC.model, main = paste("DC", lastyear))
}

#Closes the pdf file, in the sense that further plots will be displayed rather than passed to the pdf. You still need to close R Studio before you can open the file and look at them.
dev.off("R Output Files/Parameter_fit_diagnostics_onoff_reformatted.pdf")

parameters

#Creates a csv file of the parameters matrix. By default it will overwrite a file by the same name, so change the file name and/or pathway if you don't want this to happen.
write.csv(parameters, file = "R Output Files/Parameters_onoff.csv")
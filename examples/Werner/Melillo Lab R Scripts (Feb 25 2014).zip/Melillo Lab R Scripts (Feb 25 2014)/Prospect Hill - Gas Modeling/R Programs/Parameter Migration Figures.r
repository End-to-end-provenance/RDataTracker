setwd("C:/MBL_HF/Harvard Forest/Prospect Hill/Gas/Data Analysis/2014/")
library(Hmisc)
CO2<-read.csv("R Input Files/SWCO2Data.csv")
CO2$lnCO2<-log(CO2$CO2)
CO2$Date<-with(CO2, paste(Year,Month,Day,Time))
DCavgs<-with(subset(CO2, Treatment=="DC"), summarize(Temp,Date,mean))
CO2$DCavg<-DCavgs[match(CO2$Date,DCavgs$Date),2]
CO2$Delta<-CO2$Temp-CO2$DCavg

par(mar=c(8.5,5.1,1.1,2.1))
par(xpd=TRUE)

#Change year windows as desired
CO2.H.subset<-subset(CO2, Year %in% c(2008:2013) & Treatment=="H" & Delta >= 4)
CO2.C.subset<-subset(CO2,Year %in% c(2008:2013) & Treatment=="DC")

Linear.H<-lm(lm(lnCO2 ~ Temp, data=CO2.H.subset))
Intercept.H<-exp(Linear.H$coefficients[1])
Exponent.H<-Linear.H$coefficients[2]

Intercept.H
Exponent.H

Linear.C<-lm(lm(lnCO2 ~ Temp, data=CO2.C.subset))
Intercept.C<-exp(Linear.C$coefficients[1])
Exponent.C<-Linear.C$coefficients[2]

Intercept.C
Exponent.C

#Confidence Intervals
x<-seq(0,25,l=1000)
confidence3<-predict(Linear.C, data.frame(Temp=x), interval="c")
confidence3.exp<-exp(confidence3)

#Heated CIs
confidence3.h<-predict(Linear.H, data.frame(Temp=x), interval="c")
confidence3.h.exp<-exp(confidence3.h)

#Phase I Graph
par(mar=c(5.5,5.1,4.1,2.1), xpd=F, bg=NA)
curve(28.724*exp(1)^(x*0.0973),0,25, #Control 
      lty=1,lwd=2,col=4, ylim = c(0,350),
      xlab=expression (Temperature (degree*C)),
      ylab=expression(CO[2]~Flux ~(mgC ~ m^{-2}* hr^{-1})),
      main = "Phase I"
)
polygon(c(rev(x), x), c(rev(confidence1.exp[ ,3]), confidence1.exp[ ,2]), col = "lightblue", border = NA) 
polygon(c(rev(x), x), c(rev(confidence1.h.exp[ ,3]), confidence1.h.exp[ ,2]), col = "rosybrown1", border = NA)
curve(28.724*exp(1)^(x*0.0973), add=TRUE, lty=1, col="blue", lwd=2) #Replot Control over the CI
segments(17,-10,17,147.83, col=4, lwd=2, lty=3)
segments(17,147.83,-1,147.83, col=4, lwd=2, lty=3)
curve(24.72399*exp(1)^(x*0.08715), add=TRUE, lty=1, col=2, lwd=2) #Heated
segments(22,-10,22,168.187, col=2, lwd=2, lty=3)
segments(22,168.187,-1,168.187, col=2, lwd=2, lty=3)
legend(x=0, y=350,c("Control +/- 95% Confidence Interval","Heated +/- 95% Confidence Interval","Control High Modal Temperature","Heated High Modal Temperature"), lwd=2, lty=c(1,1,3,3), col=c("blue","red","blue","red"))


#Phase II Graph
par(mar=c(5.5,5.1,4.1,2.1), xpd=F, bg=NA)
curve(22.0581*exp(1)^(x*0.0929),0,25, #Control 
      lty=1,lwd=2,col=4, ylim = c(0,350),
      xlab=expression (Temperature (degree*C)),
      ylab=expression(CO[2]~Flux ~(mgC ~ m^{-2}* hr^{-1})),
      main = "Phase II"
)
polygon(c(rev(x), x), c(rev(confidence3.exp[ ,3]), confidence3.exp[ ,2]), col = "lightblue", border = NA) 
polygon(c(rev(x), x), c(rev(confidence3.h.exp[ ,3]), confidence3.h.exp[ ,2]), col = "rosybrown1", border = NA)
curve(22.0581*exp(1)^(x*0.0929), add=TRUE, lty=1, col="blue", lwd=2) #Replot Control over the CI
segments(17,-10,17,107.0162, col=4, lwd=2, lty=3)
segments(17,107.0162,-1,107.0162, col=4, lwd=2, lty=3)
curve(17.9608*exp(1)^(x*0.07995), add=TRUE, lty=1, col=2, lwd=2) #Heated
segments(22,-10,22,104.2813, col=2, lwd=2, lty=3)
segments(22,104.2813,-1,104.2813, col=2, lwd=2, lty=3)
legend(x=0, y=350,c("Control +/- 95% Confidence Interval","Heated +/- 95% Confidence Interval","Control High Modal Temperature","Heated High Modal Temperature"), lwd=2, lty=c(1,1,3,3), col=c("blue","red","blue","red"))

#Phase III Graph
par(mar=c(5.5,5.1,4.1,2.1), xpd=F, bg=NA)
curve(13.2008*exp(1)^(x*0.1267),0,25, #Control 
      lty=1,lwd=2,col=4, ylim = c(0,350),
      xlab=expression (Temperature (degree*C)),
      ylab=expression(CO[2]~Flux ~(mgC ~ m^{-2}* hr^{-1})),
      main = "Phase III"
)
polygon(c(rev(x), x), c(rev(confidence3.exp[ ,3]), confidence3.exp[ ,2]), col = "lightblue", border = NA) 
polygon(c(rev(x), x), c(rev(confidence3.h.exp[ ,3]), confidence3.h.exp[ ,2]), col = "rosybrown1", border = NA)
curve(13.2008*exp(1)^(x*0.1267), add=TRUE, lty=1, col="blue", lwd=2) #Replot Control over the CI
segments(17,-10,17,113.7698, col=4, lwd=2, lty=3)
segments(17,113.7698,-1,113.7698, col=4, lwd=2, lty=3)
curve(12.7432*exp(1)^(x*0.10574), add=TRUE, lty=1, col=2, lwd=2) #Heated
segments(22,-10,22,130.4875, col=2, lwd=2, lty=3)
segments(22,130.4875,-1,130.4875, col=2, lwd=2, lty=3)
legend(x=0, y=350,c("Control +/- 95% Confidence Interval","Heated +/- 95% Confidence Interval","Control High Modal Temperature","Heated High Modal Temperature"), lwd=2, lty=c(1,1,3,3), col=c("blue","red","blue","red"))


#1991 Graph
curve(26.483*exp(1)^(x*0.0949),0,30, #Control 
        lty=2,lwd=2,col=4, ylim = c(0,500),
        xlab=expression (Temperature (degree*C)),
        ylab=expression(CO[2]~Flux ~(mgC ~ m^{-2}* hr^{-1})),
  )
curve(21.755*exp(1)^(x*0.1035), add=TRUE, lty=1, col=2, lwd=2) #Heated
legend(x=6, y=-150,c("Control 1991","Heated 1991"), lwd=2, lty=c(2,1), col=c("blue","red"), ncol=2)


#1992-1995 Graph
curve(25.07281*exp(1)^(x*0.1133048),0,30, #Control 
      lty=1,lwd=2,col=4, ylim = c(0,500),
      xlab=expression (Temperature (degree*C)),
      ylab=expression(CO[2]~Flux ~(mgC ~ m^{-2}* hr^{-1})),
      main="1992-1995 Parameters"
)
curve(22.90478*exp(1)^(x*0.1001247), add=TRUE, lty=1, col=2, lwd=2) #Heated 

#Offset Curve Graph
curve(26.51304*exp(1)^(x*0.09418),0,25,
      lty=1,lwd=2,col="blue", ylim = c(0,350),
      xlab=expression (Control~Plot~Temperature~(degree*C)),
      ylab=expression(CO[2]~Flux ~(mgC ~ m^{-2}* hr^{-1}))
)
polygon(c(rev(x), x), c(rev(confidence.exp[ ,3]), confidence.exp[ ,2]), col = "lightblue", border = NA) #Control 
curve(26.51304*exp(1)^(x*0.09418), add=TRUE, lty=1, col="blue", lwd=2) #Replot Control over the CI
curve(28.08502*exp(1)^(x*0.07224314), add=TRUE, lty=2, col="darkred", lwd=2) #Heated
curve(28.08502*exp(1)^((x+5)*0.07224314), add=TRUE, lty=1, col="darkred", lwd=2) #Heated + 5
legend(x=0, y=350,c("Control (All Years) +/- 95% CI","Heated Phase III (Temp = Control Plot Temp)","Heated Phase III (Temp = 5 + Control Plot Temp)"), lwd=2, lty=c(1,2,1), col=c("blue","darkred","darkred"))
#Equations cross at approximately 19 deg. C

#Control All Years Curve vs. Heated Windows-----------
curve(26.51304*exp(1)^(x*0.09418),0,30,
      lty=2,lwd=2,col="blue", ylim = c(0,500),
      xlab=expression (Temperature (degree*C)),
      ylab=expression(CO[2]~Flux ~(mgC ~ m^{-2}* hr^{-1})),
)
polygon(c(rev(x), x), c(rev(confidence.exp[ ,3]), confidence.exp[ ,2]), col = "lightblue", border = NA) #Control confidence interval.
#polygon(c(rev(x), x), c(rev(confidence.h.exp[ ,3]), confidence.h.exp[ ,2]), col = "mistyrose", border = NA) #heated confidence interval for whichever window was last defined.
curve(26.51304*exp(1)^(x*0.09418), add=TRUE, lty=1, col="blue", lwd=2) #Replot Control over the CI
curve(21.755*exp(1)^(x*0.1035), add=TRUE, lty=2, col="darkred", lwd=2) #Heated 1991
curve(21.755*exp(1)^(x*0.1035), add=TRUE, lty=2, col="darkred", lwd=2) #Heated 1991
curve(26.483*exp(1)^(x*0.0949), add=TRUE, lty=2, col="blue", lwd=2) #Control 1991
curve(27.757*exp(1)^(x*0.0829), add=TRUE, lty=1, col="darkred", lwd=2) #Heated 1991-1999
curve(22.842*exp(1)^(x*0.0788), add=TRUE, lty=1, col="firebrick1", lwd=2) #Heated 2000-2005
curve(17.344*exp(1)^(x*0.0903), add=TRUE, lty=1, col="darkgoldenrod1", lwd=2) #Heated 2006-2013
legend(x=0, y=500,c("Control (All Years) +/- 95% CI","Control 1991","Heated 1991","Heated Phase I (1991-1999)","Heated Phase II (2000-2005)","Heated Phase III (2006-2013)"), lwd=2, lty=c(1,2,2,1,1,1), col=c("blue","blue","darkred","darkred","firebrick1","darkgoldenrod1"))
#mtext("Response of soil carbon dioxide emissions to temperature", side=3, line=1.5)
#mtext("at the Prospect Hill soil warming site", side=3, line=0.5)

#Control All Years Curve vs. Heated Windows-----------
curve(26.51304*exp(1)^(x*0.09418),0,25,
      lty=2,lwd=2,col="blue", ylim = c(0,300),
      xlab=expression (Temperature (degree*C)),
      ylab=expression(CO[2]~Flux ~(mgC ~ m^{-2}* hr^{-1})),
)
polygon(c(rev(x), x), c(rev(confidence.exp[ ,3]), confidence.exp[ ,2]), col = "lightblue", border = NA) #Control confidence interval.
#polygon(c(rev(x), x), c(rev(confidence.h.exp[ ,3]), confidence.h.exp[ ,2]), col = "mistyrose", border = NA) #heated confidence interval for whichever window was last defined.
curve(26.51304*exp(1)^(x*0.09418), add=TRUE, lty=2, col="blue", lwd=2) #Replot Control over the CI
#curve(21.755*exp(1)^(x*0.1035), add=TRUE, lty=2, col="darkred", lwd=2) #Heated 1991
#curve(26.483*exp(1)^(x*0.0949), add=TRUE, lty=2, col="blue", lwd=2) #Control 1991
curve(27.757*exp(1)^(x*0.0829), add=TRUE, lty=1, col="darkred", lwd=2) #Heated 1991-1999
curve(22.842*exp(1)^(x*0.0788), add=TRUE, lty=1, col="firebrick1", lwd=2) #Heated 2000-2005
curve(17.344*exp(1)^(x*0.0903), add=TRUE, lty=1, col="darkgoldenrod1", lwd=2) #Heated 2006-2013
legend(x=0, y=300,c("Control (All Years) +/- 95% CI","Heated Phase I (1991-1999)","Heated Phase II (2000-2005)","Heated Phase III (2006-2013)"), lwd=2, lty=c(2,1,1,1), col=c("blue","darkred","firebrick1","darkgoldenrod1"))
#mtext("Response of soil carbon dioxide emissions to temperature", side=3, line=1.5)
#mtext("at the Prospect Hill soil warming site", side=3, line=0.5)

#Control Windows vs. Heated Windows-----------
curve(29.59318*exp(1)^(x*0.09622),0,25,
      lty=1,lwd=2,col="darkblue", ylim = c(0,350),
      xlab=expression (Temperature (degree*C)),
      ylab=expression(CO[2]~Flux ~(mgC ~ m^{-2}* hr^{-1})), #Control 1991-1999
)
curve(24.117*exp(1)^(x*0.09412), add=TRUE, lty=1, col="blue", lwd=2) #Control 2000-2005
curve(13.7602*exp(1)^(x*0.12336), add=TRUE, lty=1, col="cadetblue", lwd=2) #Control 2006-2013
curve(25.139*exp(1)^(x*0.0871), add=TRUE, lty=1, col="darkred", lwd=2) #Heated 1991-1999
curve(19.5101*exp(1)^(x*0.0824), add=TRUE, lty=1, col="firebrick1", lwd=2) #Heated 2000-2005
curve(13.3833*exp(1)^(x*0.1003), add=TRUE, lty=1, col="darkgoldenrod1", lwd=2) #Heated 2006-2013
legend(x=0, y=350,c("Control Phase I","Control Phase II","Control Phase III","Heated Phase I","Heated Phase II","Heated Phase III"), lwd=2, lty=1, col=c("darkblue","blue","cadetblue","darkred","firebrick1","darkgoldenrod1"), ncol=2)
#mtext("Response of soil carbon dioxide emissions to temperature", side=3, line=1.5)
#mtext("at the Prospect Hill soil warming site", side=3, line=0.5)


###Yearly Control Parameters, standard 4-year windows---------------
par(mar=c(5.5,5.1,4.1,2.1))
curve(33.88*exp(1)^(x*0.092),0,25,
      lwd=2,col=1, ylim=c(0,500),
      xlab=expression (Temperature (degree*C)),
      ylab=expression(CO[2]~Flux ~(mgC ~ m^{-2}* hr^{-1}))
) #1991
curve(28.13*exp(1)^(x*0.106), add=TRUE, lwd=2, col="2")#1992
curve(30.07*exp(1)^(x*0.103), add=TRUE, lwd=2, col="3")#1993
curve(29.56*exp(1)^(x*0.107), add=TRUE, lwd=2, col="4")#1994
curve(27.9*exp(1)^(x*0.115), add=TRUE, lwd=2, col="5")#1995
curve(32.6*exp(1)^(x*0.091), add=TRUE, lwd=2, col="8")#1996
curve(29.6*exp(1)^(x*0.089), add=TRUE, lty=2, lwd=2, col="1")#1997
curve(25.12*exp(1)^(x*0.096), add=TRUE, lty=2, lwd=2, col="2")#1998
curve(25.95*exp(1)^(x*0.094), add=TRUE, lty=2, lwd=2, col="3")#1999
curve(24.57*exp(1)^(x*0.103), add=TRUE, lty=2, lwd=2, col="4")#2000
curve(23.1*exp(1)^(x*0.1), add=TRUE, lty=2, lwd=2, col="4")#2001
curve(24.66*exp(1)^(x*0.097), add=TRUE, lty=2, lwd=2, col="8")#2002
curve(23.1*exp(1)^(x*0.1), add=TRUE, lty=9, lwd=2, col="1")#2003
curve(22.6*exp(1)^(x*0.093), add=TRUE, lty=9, lwd=2, col="2")#2004
curve(24.36*exp(1)^(x*0.085), add=TRUE, lty=9, lwd=2, col="3")#2005
curve(21.83*exp(1)^(x*0.09), add=TRUE, lty=9, lwd=2, col="4")#2006
curve(20.7*exp(1)^(x*0.091), add=TRUE, lty=9, lwd=2, col="5")#2007
curve(20.95*exp(1)^(x*0.098), add=TRUE, lty=9, lwd=2, col="8")#2008
curve(16.8*exp(1)^(x*0.115), add=TRUE, lty=4, lwd=2, col="1")#2009
curve(16.36*exp(1)^(x*0.115), add=TRUE, lty=4, lwd=2, col="2")#2010
curve(17.02*exp(1)^(x*0.114), add=TRUE, lty=4, lwd=2, col="3")#2011
curve(13.44*exp(1)^(x*0.122), add=TRUE, lty=4, lwd=2, col="4")#2012
curve(9.78*exp(1)^(x*0.14), add=TRUE, lty=4, lwd=2, col="5")#2013
legend(0,500,1991:2013,lwd=2, lty=c(1,1,1,1,1,1,2,2,2,2,2,2,9,9,9,9,9,9,4,4,4,4,4), col=c(1,2,3,4,5,8,1,2,3,4,5,8,1,2,3,4,5,8,1,2,3,4,5), ncol=2)

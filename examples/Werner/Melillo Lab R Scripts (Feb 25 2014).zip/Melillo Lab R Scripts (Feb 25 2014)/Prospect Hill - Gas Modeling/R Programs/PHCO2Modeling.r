#This script takes the logger data and the output file from the PHParameters script and models daily, monthly and yearly CO2 emissions from the Prospect Hill warming site.

#I reccomend setting the Prospect Hill/Gas/Data Analysis folder to your working directory. This will make all your pathways much more managable:

setwd("C:/MBL_HF/Harvard Forest/Prospect Hill/Gas/Data Analysis/")

#This script relies on Chron package, so you will need to install it before the script can run. If chron becomes unavaliable in the future, you will have to find an alternative to the month.day.year() function used to generate month levels from julian dates.

#Imports raw data files. This needs to be updated every year to account for changes in datafile names.
Logger9197 <- read.csv("R Input Files/Logger9197.csv")
Logger9899 <- read.csv("R Input Files/Logger9899.csv")
Logger0006 <- read.csv("R Input Files/Logger0006.csv")
Logger0712 <- read.csv("R Input Files/Logger0712.csv")

#Check any datafile(s) you created or altered, even in seemingly trivial ways, to make sure it has the correct structure. If some of your columns were interperted as factors, you probably have typos or relics from excel (ie. #DIV/0!) in it. If you have exta variables at the end, you probably have blank columns in your csv file.
str(Logger9197)
str(Logger9899)
str(Logger0006)
str(Logger0712)

#Merges the raw logger data into a single dataframe. This will also need to be updated every year. 
Logger<-rbind(Logger9197,Logger9899,Logger0006,Logger0712)

#Removes any duplicate rows. There shouldn't be any, but if there are, this will get rid of them.
Logger<-unique(Logger)

#Calculates DC average and average delta.
Logger$DCavg <- round(apply(Logger[, grep("D", names(Logger))], 1, mean, na.rm = T),2)
Logger$AvgDelta <- round(apply(Logger[, grep("H", names(Logger))], 1,mean,na.rm=T)-Logger$DCavg, 2)

#Imports Wofsey and Fisher Tower data for gapfilling and merges with Logger Data.
Wofsy9199 <- read.csv("R Input Files/Wofsy9199.csv")
Wofsy0006 <- read.csv("R Input Files/Wofsy0006.csv")
Fisher <- read.csv("R Input Files/Fisher0712.csv")
Wofsy <- rbind(Wofsy9199,Wofsy0006)
Towers <- merge(Wofsy,Fisher,all.x=T,all.y=T,sort=T)
Towers <- unique(Towers)
LoggerTowers <- merge(Logger,Towers,by=c("Year","Jday","Hour"),all.x=T, sort=T)

#Calculates seperate linear models for the Wofsy and Fisher Towers, relating air temperature to DC soil temperatures.
WofsyModel <- with(LoggerTowers, lm(DCavg~WofsyTemp))
FisherModel <-with(LoggerTowers, lm(DCavg~FisherTemp))

#Uses the appropriate model to generate the modeled temperatures. Model$coefficients[2] & Model$coefficients[1] extract the slope and intercept (respectively) from the linear models generated above.
LoggerTowersW <- LoggerTowers[LoggerTowers[,"Year"]<2007,]
LoggerTowersW$ModeledTemp<-(WofsyModel$coefficients[2]*LoggerTowersW$WofsyTemp + WofsyModel$coefficients[1])
LoggerTowersF<- LoggerTowers[LoggerTowers[,"Year"]>2006,]
LoggerTowersF$ModeledTemp<-(FisherModel$coefficients[2]*LoggerTowersF$FisherTemp + FisherModel$coefficients[1])
LoggerTowers<-rbind(LoggerTowersW,LoggerTowersF)

#Keeps pre-gapfilling DC average, then fills in all missing temperatures with modeled temperatures.
LoggerGapfilled <- LoggerTowers[,c("Year","Jday","Hour","DCavg","AvgDelta")]
LoggerGapfilled$H1 <- with(LoggerTowers, ifelse(is.na(H1),ModeledTemp,H1))
LoggerGapfilled$H6 <- with(LoggerTowers, ifelse(is.na(H6),ModeledTemp,H6))
LoggerGapfilled$H8 <- with(LoggerTowers, ifelse(is.na(H8),ModeledTemp,H8))
LoggerGapfilled$H12 <- with(LoggerTowers, ifelse(is.na(H12),ModeledTemp,H12))
LoggerGapfilled$H15 <- with(LoggerTowers, ifelse(is.na(H15),ModeledTemp,H15))
LoggerGapfilled$H16 <- with(LoggerTowers, ifelse(is.na(H16),ModeledTemp,H16))
LoggerGapfilled$D3 <- with(LoggerTowers, ifelse(is.na(D3),ModeledTemp,D3))
LoggerGapfilled$D5 <- with(LoggerTowers, ifelse(is.na(D5),ModeledTemp,D5))
LoggerGapfilled$D9 <- with(LoggerTowers, ifelse(is.na(D9),ModeledTemp,D9))
LoggerGapfilled$D10 <- with(LoggerTowers, ifelse(is.na(D10),ModeledTemp,D10))
LoggerGapfilled$D13 <- with(LoggerTowers, ifelse(is.na(D13),ModeledTemp,D13))
LoggerGapfilled$D17 <- with(LoggerTowers, ifelse(is.na(D17),ModeledTemp,D17))

#Imports the parameters matrix from the Parameter derivation script. If you have run the paramter script in this same R session and have not removed any objects from your workspace you can skip/comment out the first line.
parameters<-read.csv("R Output Files/Parameters.csv")
names(parameters)[1]<-"Year"

#Calculates CO2 emissions over the course of the experiment in g CO2/m2/hr.
CO2.g.m2.hr<-merge(LoggerGapfilled, parameters[,c("Year","DC.Int","DC.Exp","H.Int","H.Exp")],by="Year",sort=T)
CO2.g.m2.hr$H1CO2<-with(CO2.g.m2.hr,(H.Int*exp(H1*H.Exp)/1000))
CO2.g.m2.hr$H6CO2<-with(CO2.g.m2.hr,(H.Int*exp(H6*H.Exp)/1000))
CO2.g.m2.hr$H8CO2<-with(CO2.g.m2.hr,(H.Int*exp(H8*H.Exp)/1000))
CO2.g.m2.hr$H12CO2<-with(CO2.g.m2.hr,(H.Int*exp(H12*H.Exp)/1000))
CO2.g.m2.hr$H15CO2<-with(CO2.g.m2.hr,(H.Int*exp(H15*H.Exp)/1000))
CO2.g.m2.hr$H16CO2<-with(CO2.g.m2.hr,(H.Int*exp(H16*H.Exp)/1000))
CO2.g.m2.hr$D3CO2<-with(CO2.g.m2.hr,(DC.Int*exp(D3*DC.Exp)/1000))
CO2.g.m2.hr$D5CO2<-with(CO2.g.m2.hr,(DC.Int*exp(D5*DC.Exp)/1000))
CO2.g.m2.hr$D9CO2<-with(CO2.g.m2.hr,(DC.Int*exp(D9*DC.Exp)/1000))
CO2.g.m2.hr$D10CO2<-with(CO2.g.m2.hr,(DC.Int*exp(D10*DC.Exp)/1000))
CO2.g.m2.hr$D13CO2<-with(CO2.g.m2.hr,(DC.Int*exp(D13*DC.Exp)/1000))
CO2.g.m2.hr$D17CO2<-with(CO2.g.m2.hr,(DC.Int*exp(D17*DC.Exp)/1000))

#Calculates CO2 emissions over the course of the experiment in g CO2/m2/day.
CO2.g.m2.day<-aggregate(CO2.g.m2.hr[,c("H1CO2","H6CO2","H8CO2","H12CO2","H15CO2","H16CO2","D3CO2","D5CO2","D9CO2","D10CO2","D13CO2","D17CO2")],CO2.g.m2.hr[,c("Jday","Year")], FUN=sum, na.rm=T)

#Uncomment the following line to get daily flux values
#write.csv(CO2.g.m2.day,"R Output Files/DailyFluxes.csv", row.names=F)

#Calculates CO2 emissions over the course of the experiment in g CO2/m2/month.
library(chron)
CO2.g.m2.hr$month<-as.factor(month.day.year(CO2.g.m2.hr$Jday)$month)
CO2.g.m2.month<-aggregate(CO2.g.m2.hr[,c("H1CO2","H6CO2","H8CO2","H12CO2","H15CO2","H16CO2","D3CO2","D5CO2","D9CO2","D10CO2","D13CO2","D17CO2")],CO2.g.m2.hr[,c("month","Year")], FUN=sum, na.rm=T)

#Uncomment the following line to get monthly flux values
#write.csv(CO2.g.m2.month,"R Output Files/MonthlyFluxes.csv", row.names=F)

#Calculates CO2 emissions over the course of the experiment in g CO2/m2/year. 
CO2.g.m2.year<-aggregate(CO2.g.m2.hr[,c("H1CO2","H6CO2","H8CO2","H12CO2","H15CO2","H16CO2","D3CO2","D5CO2","D9CO2","D10CO2","D13CO2","D17CO2")], by=list(CO2.g.m2.hr$Year), FUN=sum, na.rm=T)

#Writes a standard error function
stderr <- function(x) sd(x, na.rm=T)/sqrt(length(na.omit(x)))

#Calculates averages, standard errors, % increases, etc. for yearly fluxes.
CO2.g.m2.year$DCavg<-apply(as.matrix(CO2.g.m2.year[,8:13]),1,mean)
CO2.g.m2.year$Have<-apply(as.matrix(CO2.g.m2.year[,2:7]),1,mean)
CO2.g.m2.year$Delta<-with(CO2.g.m2.year, Have-DCavg)
CO2.g.m2.year$DCstdev<-apply(as.matrix(CO2.g.m2.year[,8:13]),1,sd)
CO2.g.m2.year$Hstdev<-apply(as.matrix(CO2.g.m2.year[,2:7]),1,sd)
CO2.g.m2.year$DCstderr<-apply(as.matrix(CO2.g.m2.year[,8:13]),1,stderr)
CO2.g.m2.year$Hstderr<-apply(as.matrix(CO2.g.m2.year[,2:7]),1,stderr)
CO2.g.m2.year$Deltastderr<-with(CO2.g.m2.year, sqrt(Hstderr^2 + DCstderr^2))
CO2.g.m2.year$PercentIncrease<-with(CO2.g.m2.year, (Have-DCavg)/DCavg)*100
CO2.g.m2.year$PctIncStdErr<-abs(with(CO2.g.m2.year, (sqrt((Hstdev/Have)^2+(DCstdev/DCavg)^2)+((DCstdev/DCavg)^2))*PercentIncrease))

#Uncomment the following line to get yearly flux values. From this point forward, it will be easier to use Excel than R.
#write.csv(CO2.g.m2.year,"R Output Files/YearlyFluxes.csv", row.names=F)

#Generates an updated summary of datalogger temperatures. This is pre-gapfilling; if you want gapfilled data, change the first line to "LoggerAllYears<-LoggerGapfilled[,-24]".
LoggerAllYears<-Logger[,-24]
LoggerAllYears$Cavg<-apply(LoggerAllYears[,c(10:15)],1,FUN=mean)
LoggerAllYears$Havg<-apply(LoggerAllYears[,c(4:9)],1,FUN=mean)
LoggerAllYears$H1Delta<-LoggerAllYears$H1-LoggerAllYears$DCavg
LoggerAllYears$H6Delta<-LoggerAllYears$H6-LoggerAllYears$DCavg
LoggerAllYears$H8Delta<-LoggerAllYears$H8-LoggerAllYears$DCavg
LoggerAllYears$H12Delta<-LoggerAllYears$H12-LoggerAllYears$DCavg
LoggerAllYears$H15Delta<-LoggerAllYears$H15-LoggerAllYears$DCavg
LoggerAllYears$H16Delta<-LoggerAllYears$H16-LoggerAllYears$DCavg

#write.csv(LoggerAllYears, "R Output Files/LoggerSummary9113.csv", row.names=F)

#Reformats this into the summary we submit to the Harvard Forest data archives.
LoggerAllYearsExp<-LoggerAllYears
LoggerAllYearsExp$Month<-month.day.year(LoggerAllYearsExp$Jday)$month
LoggerAllYearsExp$Day<-month.day.year(LoggerAllYearsExp$Jday)$day
LoggerAllYearsDaily<-aggregate(LoggerAllYearsExp[,c("Month","Day","H1","H6","H8","H12","H15","H16","D3","D5","D9","D10","D13","D17","C2","C4","C7","C11","C14","C18","DCavg","Cavg","Havg","ShedTemp")],LoggerAllYears[,c("Jday","Year")], FUN=mean, na.rm=T)

#Use this to truncate the dataset by year. We are required to submit all data within three years, so we hold back the last two years of data in the submission.
PHArchivesSummary<-subset(LoggerAllYearsDaily, Year <= 2010)

write.csv(PHArchivesSummary, "R Output Files/PHArchivesSummary.csv", row.names=F)
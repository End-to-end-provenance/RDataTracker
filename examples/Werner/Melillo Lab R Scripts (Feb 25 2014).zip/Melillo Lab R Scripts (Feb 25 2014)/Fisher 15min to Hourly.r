#This script takes the raw Fisher tower data file (15-min, metric units, 2005-present; exactally as downloaded form the harvard forest website), extracts the portions of it needed for the various purposes we use this data for, and generates output files correctly formatted for their respective purposes. Section of the script after the first importing section can be executed independently of each other)

#Imports the raw data and makes a minor tweak to the formatting to permit later use of the grep() function. This portion of the script needs to be executed for all experiments.
setwd("C:/MBL_HF/Harvard Forest/Weather/Fisher data")
RawFisher15min<-read.csv("Raw Fisher Data 140106.csv")
RawFisher15min$DateTime<-as.character(RawFisher15min$DateTime)
#After these three lines, each block encloused by tripple ### may be executed independely.

###Begin Prospect Hill CO2 Modeling###
PHFisherHourly<-RawFisher15min[grep(":00", RawFisher15min$DateTime),]
Year<-as.numeric(substr(PHFisherHourly$DateTime,1,4))
Jday<-PHFisherHourly$Jul
Hour<-as.numeric(substr(PHFisherHourly$DateTime,12,13))
FisherTemp<-PHFisherHourly$AirT
PHFisherHourlyAllYears<-data.frame(Year,Jday,Hour,FisherTemp)
#Prior to 2007 we use the Wofsy data for gapfilling.
PHFisherHourlyFinal<-PHFisherHourlyAllYears[PHFisherHourlyAllYears[,"Year"]>=2007,]
write.csv(PHFisherHourlyFinal,"Fisher0713.csv", row.names=F)
###End Prospect Hill CO2 Modeling###

###Begin Hot Plants Environmental Data###
HPFisherHourly<-RawFisher15min[grep(":00", RawFisher15min$DateTime),]
Year<-as.numeric(substr(HPFisherHourly$DateTime,1,4))
Hour<-as.numeric(substr(HPFisherHourly$DateTime,12,13))
Jday<-HPFisherHourly$Jul
HPFisherData<-data.frame(Year,Hour,Jday,HPFisherHourly[,c(3,5,9,11,13,19,21,23,29)])
HPFisherFinal<-HPFisherData[HPFisherData[,"Year"]>=2009,]
write.csv(HPFisherFinal, "FisherHourly_04.15.13.csv", row.names=F)
###End Hot Plants Environmental Data###
###Initial Setup--------------------
#I reccomend setting the Barre Woods/NMIN/NMIN Analyses folder to your working directory. This will make all your pathways much more managable:
setwd("C:/MBL_HF/Harvard Forest/Barre Woods/NMIN/NMIN Analyses/2013/")

#What are the first and last sampling dates in YYYY-MM-DD format? (This needs to be updated every year)
firstdate<-as.Date("2002-05-07")
lastdate<-as.Date("2012-11-04")

###Preliminary Calculations, Initial-Final Matching-----------
#Imports raw NMIN data and converts NH4 & NO3 measurements into mg N/kg soil.
RawNMIN<-read.csv("R Input Files/BWNMINdata.csv")
RawNMIN$WetWeight<-with(RawNMIN, WetTin-TinWeight)
RawNMIN$DryWeight<-with(RawNMIN, DryTin-TinWeight)
RawNMIN$SoilMoisture<-with(RawNMIN, (WetWeight-DryWeight)/DryWeight)
RawNMIN$DrySoilWt<-with(RawNMIN, SoilJar/(SoilMoisture+1))
#If a measurement is negative, then make it 0 instead.
RawNMIN$NH4<-with(RawNMIN, ifelse(NH4corr>0,NH4corr,0))
RawNMIN$NO3<-with(RawNMIN, ifelse(NO3corr>0,NO3corr,0))
RawNMIN$NH4mgkg<-with(RawNMIN, ((NH4*KCl)/DrySoilWt)*(10^3))
RawNMIN$NO3mgkg<-with(RawNMIN, ((NO3*KCl)/DrySoilWt)*(10^3))

#Pairs initial samples with their corresponding final sample and merges them into a simplified dataframe.
RawNMIN$Pair<-with(RawNMIN, ifelse(Incubation=="initial",Sample+100,Sample))
RawNMIN$Pair<-paste(RawNMIN$Pair, RawNMIN$Horizon)
RawNMIN$iNH4mgkg<-with(RawNMIN, ifelse(Incubation=="initial", NH4mgkg,NA))
RawNMIN$iNO3mgkg<-with(RawNMIN, ifelse(Incubation=="initial", NO3mgkg,NA))
RawNMIN$fNH4mgkg<-with(RawNMIN, ifelse(Incubation=="final", NH4mgkg,NA))
RawNMIN$fNO3mgkg<-with(RawNMIN, ifelse(Incubation=="final", NO3mgkg,NA))
RawInitials<-subset(RawNMIN[,c("Year","Incubation","Sample","Horizon","Treatment","Plot","PlotID","Pair","iNH4mgkg","iNO3mgkg")], Incubation=="initial")
names(RawInitials)[3]<-"iSample"
RawFinals<-subset(RawNMIN[,c("Year","Incubation","Sample","Horizon","Treatment","Plot","PlotID","Pair","fNH4mgkg","fNO3mgkg")], Incubation=="final")
names(RawFinals)[3]<-"fSample"
RawPaired<-RawInitials
RawPaired$fSample<-RawFinals[match(RawPaired$Pair,RawFinals$Pair),"fSample"]
RawPaired$fNH4mgkg<-RawFinals[match(RawPaired$Pair,RawFinals$Pair),"fNH4mgkg"]
RawPaired$fNO3mgkg<-RawFinals[match(RawPaired$Pair,RawFinals$Pair),"fNO3mgkg"]

#Calculates minerialization between inital and final samples.
RawPaired$netNH4<-with(RawPaired, fNH4mgkg-iNH4mgkg)
RawPaired$netNO3<-with(RawPaired, fNO3mgkg-iNO3mgkg)

###Incubation Date Assignment------------
#Assigns initial and final dates to each pair of samples by their sample numbers. Dates must be in yyyy-mm-dd format. IncubationNumber assigns a unique ID number to each incubation period. This section will need to be appended every year with the year's sampling dates and numbers, and each incubation given an incubation number.
RawPaired$iDate[RawPaired$iSample %in% c(1000:1039)] <- "2002-05-07"
RawPaired$fDate[RawPaired$fSample %in% c(1100:1139)] <- "2002-06-11"
RawPaired$IncubationNumber[RawPaired$fSample %in% c(1100:1139)] <- 1

RawPaired$iDate[RawPaired$iSample %in% c(1040:1079)] <- "2002-06-11"
RawPaired$fDate[RawPaired$fSample %in% c(1140:1179)] <- "2002-07-15"
RawPaired$IncubationNumber[RawPaired$fSample %in% c(1140:1179)] <- 2

RawPaired$iDate[RawPaired$iSample %in% c(1080:1099,1200:1219)] <- "2002-07-15"
RawPaired$fDate[RawPaired$fSample %in% c(1180:1199,1300:1319)] <- "2002-08-19"
RawPaired$IncubationNumber[RawPaired$fSample %in% c(1180:1199,1300:1319)] <- 3

RawPaired$iDate[RawPaired$iSample %in% c(1220:1259)] <- "2002-08-19"
RawPaired$fDate[RawPaired$fSample %in% c(1320:1359)] <- "2002-09-23"
RawPaired$IncubationNumber[RawPaired$fSample %in% c(1320:1359)] <- 4

RawPaired$iDate[RawPaired$iSample %in% c(1260:1299)] <- "2002-09-23"
RawPaired$fDate[RawPaired$fSample %in% c(1360:1399)] <- "2002-10-28"
RawPaired$IncubationNumber[RawPaired$fSample %in% c(1360:1399)] <- 5

RawPaired$iDate[RawPaired$iSample %in% c(1400:1439)] <- "2002-10-28"
RawPaired$fDate[RawPaired$fSample %in% c(1500:1539)] <- "2003-04-15"
RawPaired$IncubationNumber[RawPaired$fSample %in% c(1500:1539)] <- 6

RawPaired$iDate[RawPaired$iSample %in% c(1440:1479)] <- "2003-04-15"
RawPaired$fDate[RawPaired$fSample %in% c(1540:1579)] <- "2003-05-05"
RawPaired$IncubationNumber[RawPaired$fSample %in% c(1540:1579)] <- 7

RawPaired$iDate[RawPaired$iSample %in% c(1480:1499,1600:1619)] <- "2003-05-05"
RawPaired$fDate[RawPaired$fSample %in% c(1580:1599,1700:1719)] <- "2003-06-23"
RawPaired$IncubationNumber[RawPaired$fSample %in% c(1580:1599,1700:1719)] <- 8

RawPaired$iDate[RawPaired$iSample %in% c(1620:1659)] <- "2003-06-23"
RawPaired$fDate[RawPaired$fSample %in% c(1720:1759)] <- "2003-07-28"
RawPaired$IncubationNumber[RawPaired$fSample %in% c(1720:1759)] <- 9

RawPaired$iDate[RawPaired$iSample %in% c(1660:1699)] <- "2003-07-28"
RawPaired$fDate[RawPaired$fSample %in% c(1760:1799)] <- "2003-09-02"
RawPaired$IncubationNumber[RawPaired$fSample %in% c(1760:1799)] <- 10

RawPaired$iDate[RawPaired$iSample %in% c(1800:1839)] <- "2003-09-02"
RawPaired$fDate[RawPaired$fSample %in% c(1900:1939)] <- "2003-10-06"
RawPaired$IncubationNumber[RawPaired$fSample %in% c(1900:1939)] <- 11

RawPaired$iDate[RawPaired$iSample %in% c(1840:1879)] <- "2003-10-06"
RawPaired$fDate[RawPaired$fSample %in% c(1940:1979)] <- "2003-11-10"
RawPaired$IncubationNumber[RawPaired$fSample %in% c(1940:1979)] <- 12

RawPaired$iDate[RawPaired$iSample %in% c(1880:1899,2000:2019)] <- "2003-11-10"
RawPaired$fDate[RawPaired$fSample %in% c(1980:1999,2100:2119)] <- "2004-04-12"
RawPaired$IncubationNumber[RawPaired$fSample %in% c(1980:1999,2100:2119)] <- 13

RawPaired$iDate[RawPaired$iSample %in% c(2020:2059)] <- "2004-04-12"
RawPaired$fDate[RawPaired$fSample %in% c(2120:2159)] <- "2004-05-24"
RawPaired$IncubationNumber[RawPaired$fSample %in% c(2120:2159)] <- 14

RawPaired$iDate[RawPaired$iSample %in% c(2060:2099)] <- "2004-05-24"
RawPaired$fDate[RawPaired$fSample %in% c(2160:2199)] <- "2004-06-21"
RawPaired$IncubationNumber[RawPaired$fSample %in% c(2160:2199)] <- 15

RawPaired$iDate[RawPaired$iSample %in% c(2200:2239)] <- "2004-06-21"
RawPaired$fDate[RawPaired$fSample %in% c(2300:2339)] <- "2004-07-26"
RawPaired$IncubationNumber[RawPaired$fSample %in% c(2300:2339)] <- 16

RawPaired$iDate[RawPaired$iSample %in% c(2240:2279)] <- "2004-07-26"
RawPaired$fDate[RawPaired$fSample %in% c(2340:2379)] <- "2004-08-30"
RawPaired$IncubationNumber[RawPaired$fSample %in% c(2340:2379)] <- 17

RawPaired$iDate[RawPaired$iSample %in% c(2280:2299,2400:2419)] <- "2004-08-30"
RawPaired$fDate[RawPaired$fSample %in% c(2380:2399,2500:2519)] <- "2004-10-04"
RawPaired$IncubationNumber[RawPaired$fSample %in% c(2380:2399,2500:2519)] <- 18

RawPaired$iDate[RawPaired$iSample %in% c(2420:2459)] <- "2004-10-04"
RawPaired$fDate[RawPaired$fSample %in% c(2520:2559)] <- "2004-12-09"
RawPaired$IncubationNumber[RawPaired$fSample %in% c(2520:2559)] <- 19

RawPaired$iDate[RawPaired$iSample %in% c(2460:2499)] <- "2004-12-09"
RawPaired$fDate[RawPaired$fSample %in% c(2560:2599)] <- "2005-04-19"
RawPaired$IncubationNumber[RawPaired$fSample %in% c(2560:2599)] <- 20

RawPaired$iDate[RawPaired$iSample %in% c(2600:2639)] <- "2005-04-19"
RawPaired$fDate[RawPaired$fSample %in% c(2700:2739)] <- "2005-05-17"
RawPaired$IncubationNumber[RawPaired$fSample %in% c(2700:2739)] <- 21

RawPaired$iDate[RawPaired$iSample %in% c(2640:2679)] <- "2005-05-17"
RawPaired$fDate[RawPaired$fSample %in% c(2740:2779)] <- "2005-06-28"
RawPaired$IncubationNumber[RawPaired$fSample %in% c(2740:2779)] <- 22

RawPaired$iDate[RawPaired$iSample %in% c(2680:2699,2800:2819)] <- "2005-06-28"
RawPaired$fDate[RawPaired$fSample %in% c(2780:2799,2900:2919)] <- "2005-07-25"
RawPaired$IncubationNumber[RawPaired$fSample %in% c(2780:2799,2900:2919)] <- 23

RawPaired$iDate[RawPaired$iSample %in% c(2820:2859)] <- "2005-07-25"
RawPaired$fDate[RawPaired$fSample %in% c(2920:2959)] <- "2005-09-06"
RawPaired$IncubationNumber[RawPaired$fSample %in% c(2920:2959)] <- 24

RawPaired$iDate[RawPaired$iSample %in% c(2860:2899)] <- "2005-09-06"
RawPaired$fDate[RawPaired$fSample %in% c(2960:2999)] <- "2005-10-20"
RawPaired$IncubationNumber[RawPaired$fSample %in% c(2960:2999)] <- 25

RawPaired$iDate[RawPaired$iSample %in% c(3000:3039)] <- "2005-10-20"
RawPaired$fDate[RawPaired$fSample %in% c(3100:3139)] <- "2005-11-14"
RawPaired$IncubationNumber[RawPaired$fSample %in% c(3100:3139)] <- 26

RawPaired$iDate[RawPaired$iSample %in% c(3040:3079)] <- "2005-11-14"
RawPaired$fDate[RawPaired$fSample %in% c(3140:3179)] <- "2006-04-24"
RawPaired$IncubationNumber[RawPaired$fSample %in% c(3140:3179)] <- 27

RawPaired$iDate[RawPaired$iSample %in% c(3080:3099,3200:3219)] <- "2006-04-24"
RawPaired$fDate[RawPaired$fSample %in% c(3180:3199,3300:3319)] <- "2006-06-13"
RawPaired$IncubationNumber[RawPaired$fSample %in% c(3180:3199,3300:3319)] <- 28

RawPaired$iDate[RawPaired$iSample %in% c(3220:3259)] <- "2006-06-13"
RawPaired$fDate[RawPaired$fSample %in% c(3320:3359)] <- "2006-07-18"
RawPaired$IncubationNumber[RawPaired$fSample %in% c(3320:3359)] <- 29

RawPaired$iDate[RawPaired$iSample %in% c(3260:3299)] <- "2006-07-18"
RawPaired$fDate[RawPaired$fSample %in% c(3360:3399)] <- "2006-09-12"
RawPaired$IncubationNumber[RawPaired$fSample %in% c(3360:3399)] <- 30

RawPaired$iDate[RawPaired$iSample %in% c(3400:3439)] <- "2006-09-12"
RawPaired$fDate[RawPaired$fSample %in% c(3500:3539)] <- "2006-10-16"
RawPaired$IncubationNumber[RawPaired$fSample %in% c(3500:3539)] <- 31

RawPaired$iDate[RawPaired$iSample %in% c(3440:3479)] <- "2006-10-16"
RawPaired$fDate[RawPaired$fSample %in% c(3540:3579)] <- "2006-11-13"
RawPaired$IncubationNumber[RawPaired$fSample %in% c(3540:3579)] <- 32

RawPaired$iDate[RawPaired$iSample %in% c(3480:3499,3600:3619)] <- "2006-11-13"
RawPaired$fDate[RawPaired$fSample %in% c(3580:3599,3700:3719)] <- "2007-04-24"
RawPaired$IncubationNumber[RawPaired$fSample %in% c(3580:3599,3700:3719)] <- 33

RawPaired$iDate[RawPaired$iSample %in% c(3620:3659)] <- "2007-04-24"
RawPaired$fDate[RawPaired$fSample %in% c(3720:3759)] <- "2007-06-05"
RawPaired$IncubationNumber[RawPaired$fSample %in% c(3720:3759)] <- 34

RawPaired$iDate[RawPaired$iSample %in% c(3660:3699)] <- "2007-06-05"
RawPaired$fDate[RawPaired$fSample %in% c(3760:3799)] <- "2007-07-10"
RawPaired$IncubationNumber[RawPaired$fSample %in% c(3760:3799)] <- 35

RawPaired$iDate[RawPaired$iSample %in% c(3800:3839)] <- "2007-07-10"
RawPaired$fDate[RawPaired$fSample %in% c(3900:3939)] <- "2007-08-07"
RawPaired$IncubationNumber[RawPaired$fSample %in% c(3900:3939)] <- 36

RawPaired$iDate[RawPaired$iSample %in% c(3840:3879)] <- "2007-08-07"
RawPaired$fDate[RawPaired$fSample %in% c(3940:3979)] <- "2007-09-18"
RawPaired$IncubationNumber[RawPaired$fSample %in% c(3940:3979)] <- 37

RawPaired$iDate[RawPaired$iSample %in% c(3880:3899,4000:4019)] <- "2007-09-18"
RawPaired$fDate[RawPaired$fSample %in% c(3980:3999,4100:4119)] <- "2007-10-23"
RawPaired$IncubationNumber[RawPaired$fSample %in% c(3980:3999,4100:4119)] <- 38

RawPaired$iDate[RawPaired$iSample %in% c(4020:4059)] <- "2007-10-23"
RawPaired$fDate[RawPaired$fSample %in% c(4120:4159)] <- "2007-11-13"
RawPaired$IncubationNumber[RawPaired$fSample %in% c(4120:4159)] <- 39

RawPaired$iDate[RawPaired$iSample %in% c(4060:4099)] <- "2007-11-13"
RawPaired$fDate[RawPaired$fSample %in% c(4160:4199)] <- "2008-04-22"
RawPaired$IncubationNumber[RawPaired$fSample %in% c(4160:4199)] <- 40

RawPaired$iDate[RawPaired$iSample %in% c(4200:4239)] <- "2008-04-22"
RawPaired$fDate[RawPaired$fSample %in% c(4300:4339)] <- "2008-05-27"
RawPaired$IncubationNumber[RawPaired$fSample %in% c(4300:4339)] <- 41

RawPaired$iDate[RawPaired$iSample %in% c(4240:4279)] <- "2008-05-27"
RawPaired$fDate[RawPaired$fSample %in% c(4340:4379)] <- "2008-06-24"
RawPaired$IncubationNumber[RawPaired$fSample %in% c(4340:4379)] <- 42

RawPaired$iDate[RawPaired$iSample %in% c(4280:4299,4400:4419)] <- "2008-06-24"
RawPaired$fDate[RawPaired$fSample %in% c(4380:4399,4500:4519)] <- "2008-07-28"
RawPaired$IncubationNumber[RawPaired$fSample %in% c(4380:4399,4500:4519)] <- 43

RawPaired$iDate[RawPaired$iSample %in% c(4420:4459)] <- "2008-07-28"
RawPaired$fDate[RawPaired$fSample %in% c(4520:4559)] <- "2008-09-02"
RawPaired$IncubationNumber[RawPaired$fSample %in% c(4520:4559)] <- 44

RawPaired$iDate[RawPaired$iSample %in% c(4460:4499)] <- "2008-09-02"
RawPaired$fDate[RawPaired$fSample %in% c(4560:4599)] <- "2008-11-04"
RawPaired$IncubationNumber[RawPaired$fSample %in% c(4560:4599)] <- 45

RawPaired$iDate[RawPaired$iSample %in% c(4600:4639)] <- "2008-11-04"
RawPaired$fDate[RawPaired$fSample %in% c(4700:4739)] <- "2009-04-20"
RawPaired$IncubationNumber[RawPaired$fSample %in% c(4700:4739)] <- 46

RawPaired$iDate[RawPaired$iSample %in% c(4640:4679)] <- "2009-04-20"
RawPaired$fDate[RawPaired$fSample %in% c(4740:4779)] <- "2009-06-01"
RawPaired$IncubationNumber[RawPaired$fSample %in% c(4740:4779)] <- 47

RawPaired$iDate[RawPaired$iSample %in% c(4680:4699,4800:4819)] <- "2009-06-01"
RawPaired$fDate[RawPaired$fSample %in% c(4780:4799,4900:4919)] <- "2009-07-13"
RawPaired$IncubationNumber[RawPaired$fSample %in% c(4780:4799,4900:4919)] <- 48

RawPaired$iDate[RawPaired$iSample %in% c(4820:4859)] <- "2009-07-13"
RawPaired$fDate[RawPaired$fSample %in% c(4920:4959)] <- "2009-08-17"
RawPaired$IncubationNumber[RawPaired$fSample %in% c(4920:4959)] <- 49

RawPaired$iDate[RawPaired$iSample %in% c(4860:4899)] <- "2009-08-17"
RawPaired$fDate[RawPaired$fSample %in% c(4960:4999)] <- "2009-10-05"
RawPaired$IncubationNumber[RawPaired$fSample %in% c(4960:4999)] <- 50

RawPaired$iDate[RawPaired$iSample %in% c(5000:5039)] <- "2009-10-05"
RawPaired$fDate[RawPaired$fSample %in% c(5100:5139)] <- "2009-11-13"
RawPaired$IncubationNumber[RawPaired$fSample %in% c(5100:5139)] <- 51

RawPaired$iDate[RawPaired$iSample %in% c(5040:5079)] <- "2009-11-13"
RawPaired$fDate[RawPaired$fSample %in% c(5140:5179)] <- "2010-05-03"
RawPaired$IncubationNumber[RawPaired$fSample %in% c(5140:5179)] <- 52

RawPaired$iDate[RawPaired$iSample %in% c(5080:5099,5200:5219)] <- "2010-05-03"
RawPaired$fDate[RawPaired$fSample %in% c(5180:5199,5300:5319)] <- "2010-06-07"
RawPaired$IncubationNumber[RawPaired$fSample %in% c(5180:5199,5300:5319)] <- 53

RawPaired$iDate[RawPaired$iSample %in% c(5220:5259)] <- "2010-06-07"
RawPaired$fDate[RawPaired$fSample %in% c(5320:5359)] <- "2010-07-20"
RawPaired$IncubationNumber[RawPaired$fSample %in% c(5320:5359)] <- 54

RawPaired$iDate[RawPaired$iSample %in% c(5260:5299)] <- "2010-07-20"
RawPaired$fDate[RawPaired$fSample %in% c(5360:5399)] <- "2010-08-17"
RawPaired$IncubationNumber[RawPaired$fSample %in% c(5360:5399)] <- 55

RawPaired$iDate[RawPaired$iSample %in% c(5400:5439)] <- "2010-08-17"
RawPaired$fDate[RawPaired$fSample %in% c(5500:5539)] <- "2010-10-04"
RawPaired$IncubationNumber[RawPaired$fSample %in% c(5500:5539)] <- 56

RawPaired$iDate[RawPaired$iSample %in% c(5440:5479)] <- "2010-10-04"
RawPaired$fDate[RawPaired$fSample %in% c(5540:5579)] <- "2010-11-01"
RawPaired$IncubationNumber[RawPaired$fSample %in% c(5540:5579)] <- 57

RawPaired$iDate[RawPaired$iSample %in% c(5480:5499,5600:5619)] <- "2010-11-01"
RawPaired$fDate[RawPaired$fSample %in% c(5580:5599,5700:5719)] <- "2011-04-26"
RawPaired$IncubationNumber[RawPaired$fSample %in% c(5580:5599,5700:5719)] <- 58

RawPaired$iDate[RawPaired$iSample %in% c(5620:5659)] <- "2011-04-26"
RawPaired$fDate[RawPaired$fSample %in% c(5720:5759)] <- "2011-05-30"
RawPaired$IncubationNumber[RawPaired$fSample %in% c(5720:5759)] <- 59

RawPaired$iDate[RawPaired$iSample %in% c(5660:5699)] <- "2011-05-30"
RawPaired$fDate[RawPaired$fSample %in% c(5760:5799)] <- "2011-07-05"
RawPaired$IncubationNumber[RawPaired$fSample %in% c(5760:5799)] <- 60

RawPaired$iDate[RawPaired$iSample %in% c(5800:5839)] <- "2011-07-05"
RawPaired$fDate[RawPaired$fSample %in% c(5900:5939)] <- "2011-08-08"
RawPaired$IncubationNumber[RawPaired$fSample %in% c(5900:5939)] <- 61

RawPaired$iDate[RawPaired$iSample %in% c(5840:5879)] <- "2011-08-08"
RawPaired$fDate[RawPaired$fSample %in% c(5940:5979)] <- "2011-09-13"
RawPaired$IncubationNumber[RawPaired$fSample %in% c(5940:5979)] <- 62

RawPaired$iDate[RawPaired$iSample %in% c(5880:5899,6000:6019)] <- "2011-09-13"
RawPaired$fDate[RawPaired$fSample %in% c(5980:5999,6100:6119)] <- "2011-11-07"
RawPaired$IncubationNumber[RawPaired$fSample %in% c(5980:5999,6100:6119)] <- 63

RawPaired$iDate[RawPaired$iSample %in% c(6020:6059)] <- "2011-11-07"
RawPaired$fDate[RawPaired$fSample %in% c(6120:6159)] <- "2012-04-24"
RawPaired$IncubationNumber[RawPaired$fSample %in% c(6120:6159)] <- 64

RawPaired$iDate[RawPaired$iSample %in% c(6060:6099)] <- "2012-04-24"
RawPaired$fDate[RawPaired$fSample %in% c(6160:6199)] <- "2012-06-29"
RawPaired$IncubationNumber[RawPaired$fSample %in% c(6160:6199)] <- 65

RawPaired$iDate[RawPaired$iSample %in% c(6200:6239)] <- "2012-06-29"
RawPaired$fDate[RawPaired$fSample %in% c(6300:6339)] <- "2012-09-10"
RawPaired$IncubationNumber[RawPaired$fSample %in% c(6300:6339)] <- 66

RawPaired$iDate[RawPaired$iSample %in% c(6240:6279)] <- "2012-09-10"
RawPaired$fDate[RawPaired$fSample %in% c(6340:6379)] <- "2012-11-04"
RawPaired$IncubationNumber[RawPaired$fSample %in% c(6340:6379)] <- 67

###Mineralization per Incubation Calculations----------------
#Calculates the length of each incubation in days.
RawPaired$Time<-as.numeric(difftime(RawPaired$fDate,RawPaired$iDate,units="days"))

#Calculates mineralization rates on a per-day basis and creates a simplified dataframe.
RawPaired$NH4.mg.kg.day<-with(RawPaired, netNH4/Time)
RawPaired$NO3.mg.kg.day<-with(RawPaired, netNO3/Time)
RawPaired$ION.mg.kg.day<-with(RawPaired, NH4.mg.kg.day + NO3.mg.kg.day)
NetMIN<-RawPaired[c("iDate","fDate","Horizon","Treatment","Plot","PlotID","NH4.mg.kg.day","NO3.mg.kg.day","ION.mg.kg.day","Time","IncubationNumber")]

#Inputs depth of each horizon; 1.4 cm for organic, 10 cm for mineral.
NetMIN$depth<-ifelse(NetMIN$Horizon==0, 1.4, 10)

#Inputs bulk density of each horizon; 0.3730 for organic, 0.7811 for mineral. Then converts rates from mg N/kg soil into kg N/hectare.
####NOTE: These values were re-measured in 2010 and found to be different. We might consider remeasuring them in the future to ensure that the 2010 measurement was not in error. If checking vindicates the 2010 measurements, we might consider finding a way to incorporate a non-static bulk density into this analysis.
NetMIN$BulkDensity<-ifelse(NetMIN$Horizon==0, 0.3730, 0.7811)
NetMIN$AerialDensity<-with(NetMIN, (depth*BulkDensity)/10)
NetMIN$NH4.kg.ha.day<-with(NetMIN, NH4.mg.kg.day*AerialDensity)
NetMIN$NO3.kg.ha.day<-with(NetMIN, NO3.mg.kg.day*AerialDensity)
NetMIN$ION.kg.ha.day<-with(NetMIN, ION.mg.kg.day*AerialDensity)

#Averages rates between replicate subplots, ignoring missing values.
AvgMIN<-aggregate(NetMIN[,c("NH4.kg.ha.day","NO3.kg.ha.day","ION.kg.ha.day")],NetMIN[,c("iDate","fDate","Horizon","Treatment","Plot","IncubationNumber")], FUN = mean, na.rm=T)

###Scaling from Incubations to Calander Units-----------------
#Creates a dataframe containing every day between the first and last sampling days, trimming off the last day of sampling (this line would normally recieve the overwinter rates, which you won't have yet), and assigns the correct incubation period to each day.
allDates<-seq(as.Date(firstdate), as.Date(lastdate), by="day")
allDates<-data.frame(allDates[-length(allDates)])
names(allDates)[1]<-"Date"
allDates$IncubationNumber <- NA
Incubations<-RawPaired[,c("iDate","fDate","IncubationNumber")]
Incubations<-aggregate(Incubations[,"IncubationNumber"], Incubations[,c("iDate","fDate")],FUN=mean)
names(Incubations)[3]<-"IncubationNumber"

#This loop is a dense block of script. Basically it reads: For each row "i" in the allDates dataframe, look up the Incubation Number in the Incubations dataframe that meets two criteria. 1) The idate in the Incubations dataframe is less than or equal to the date in the allDates dataframe and 2) the fdate in the Incubations dataframe is greater than the date in the allDAtes dataframe. I find more intuitive to think of this backwards (ie. the date in the allDates dataframe is greater than or equal to the idate in the Incubations dataframe), but the scripting works better the other way around. This should narrow the dataframe down to exactally one cell - if it doesn't, you have a problem in the datafiles - and by coercing it to a numeric object it can be put into a single cell in the allDates dataframe. as.Date() and unclass() are necessairy to faciliate logical comparisons of dates, as up to this point they have been stored as character strings.
for (i in 1:dim(allDates)[1]) {
  allDates[i,"IncubationNumber"] <- as.numeric(Incubations[as.Date(unclass(Incubations$iDate))<=allDates[i,"Date"]&as.Date(unclass(Incubations$fDate))>allDates[i,"Date"],"IncubationNumber"])
}

#If you click on allDates in the R Studio workspace window, it will display your dates as the number of days elapsed since January 1st 1970. If you want to check the dataframe and have them display as dates in conventaitonal format, use str(allDates) or head(allDates).

#Fills in each day elapsed since the first measurement with the rates corresponding to the incubation it falls under.
NMINdays<-merge(allDates,AvgMIN,by="IncubationNumber")

###Final Calculations-----------------
#Calcualtes monthly minerializaiton.
NMINdays$Year<-1900+as.POSIXlt(NMINdays$Date)$year 
NMINdays$Month<-1+as.POSIXlt(NMINdays$Date)$mon
NMINMonths<-aggregate(NMINdays[,c("NH4.kg.ha.day","NO3.kg.ha.day","ION.kg.ha.day")],NMINdays[,c("Plot","Horizon","Treatment","Month","Year")], FUN = sum, na.rm=T)
names(NMINMonths)[c(6,7,8)]<-c("NH4.kg.ha.month","NO3.kg.ha.month","ION.kg.ha.month")

#Creates standard error functions.
stderr <- function(x) sd(x, na.rm=T)/sqrt(length(na.omit(x)))
stderr.add <- function(x,y) sqrt(x^2 + y^2)

#Calculates minerialization by horizon, treatment, and date (averaging across plots).
NMINMonths.organic<-subset(NMINMonths, Horizon==0)
NMINorganic<-aggregate(NMINMonths.organic[,c("NH4.kg.ha.month","NO3.kg.ha.month","ION.kg.ha.month")],NMINMonths.organic[,c("Horizon","Treatment","Month","Year")], FUN = mean, na.rm = T)
NMINorganic.stderr<-aggregate(NMINMonths.organic[,c("NH4.kg.ha.month","NO3.kg.ha.month","ION.kg.ha.month")],NMINMonths.organic[,c("Horizon","Treatment","Month","Year")], FUN = stderr)

NMINMonths.mineral<-subset(NMINMonths, Horizon==3)
NMINmineral<-aggregate(NMINMonths.mineral[,c("NH4.kg.ha.month","NO3.kg.ha.month","ION.kg.ha.month")],NMINMonths.mineral[,c("Horizon","Treatment","Month","Year")], FUN = mean, na.rm = T)
NMINmineral.stderr<-aggregate(NMINMonths.mineral[,c("NH4.kg.ha.month","NO3.kg.ha.month","ION.kg.ha.month")],NMINMonths.mineral[,c("Horizon","Treatment","Month","Year")], FUN = stderr)

#Sums mineral and organic horizons for total mineralization by treatment and date.
NMINTotal<-NMINorganic[,-1]
NMINTotal[,c("NH4.kg.ha.month","NO3.kg.ha.month","ION.kg.ha.month")]<-NMINorganic[,c("NH4.kg.ha.month","NO3.kg.ha.month","ION.kg.ha.month")] + NMINmineral[,c("NH4.kg.ha.month","NO3.kg.ha.month","ION.kg.ha.month")]
NMINTotal.stderr<-NMINorganic[,-1]
NMINTotal.stderr[,c("NH4.kg.ha.month","NO3.kg.ha.month","ION.kg.ha.month")]<-stderr.add(NMINorganic.stderr[,c("NH4.kg.ha.month","NO3.kg.ha.month","ION.kg.ha.month")], NMINmineral.stderr[,c("NH4.kg.ha.month","NO3.kg.ha.month","ION.kg.ha.month")])

#Merges the total and standard error dataframes for export.
NMINFinal<-merge(NMINTotal,NMINTotal.stderr, by=c("Treatment","Year","Month"))
names(NMINFinal)<-c("Treatment","Year","Month","NH4","NO3","ION","StdErrNH4","StdErrNO3","StdErrION")
NMINFinal$Month2<-month.name[NMINFinal$Month]
NMINFinal$WarmYear<-with(NMINFinal, ifelse(Month>=5,paste("Year",Year-2002),paste("Year",Year-2003)))
write.csv(NMINFinal, "R Output Files/TotalNMIN.csv", row.names=F)

#Does the same thing as above, but keeping the horizons seperate.
Horizons<-rbind(NMINorganic,NMINmineral)
HorizonsErr<-rbind(NMINorganic.stderr,NMINmineral.stderr)
NMINHorizons<-merge(Horizons,HorizonsErr,by=c("Treatment","Year","Month","Horizon"))
names(NMINHorizons)<-c("Treatment","Year","Month","Horizon","NH4","NO3","ION","StdErrNH4","StdErrNO3","StdErrION")
NMINHorizons$Month2<-month.name[NMINHorizons$Month]
NMINHorizons$WarmYear<-with(NMINHorizons, ifelse(Month>=5,paste("Year",Year-2002),paste("Year",Year-2003)))
write.csv(NMINHorizons, "R Output Files/HorizonsNMIN.csv", row.names=F)

#Reshapes the dataframes into wide format for export, mimicing the format in the pre-2013 Excel sheet. This is not used in current analyses.
#NMINTotal.Export<-reshape(NMINTotal, timevar="Month", v.names=c("NH4.kg.ha.month","NO3.kg.ha.month","ION.kg.ha.month"), idvar=c("Year","Treatment"), direction="wide",sep=".")
#NMINTotal.stderr.Export<-reshape(NMINTotal.stderr, timevar="Month", v.names=c("NH4.kg.ha.month","NO3.kg.ha.month","ION.kg.ha.month"), idvar=c("Year","Treatment"), direction="wide",sep=".")

#NMINOrganic.Export<-reshape(NMINorganic, timevar="Month", v.names=c("NH4.kg.ha.month","NO3.kg.ha.month","ION.kg.ha.month"), idvar=c("Year","Treatment"), direction="wide",sep=".")
#NMINOrganic.stderr.Export<-reshape(NMINorganic.stderr, timevar="Month", v.names=c("NH4.kg.ha.month","NO3.kg.ha.month","ION.kg.ha.month"), idvar=c("Year","Treatment"), direction="wide",sep=".")

#NMINMineral.Export<-reshape(NMINmineral, timevar="Month", v.names=c("NH4.kg.ha.month","NO3.kg.ha.month","ION.kg.ha.month"), idvar=c("Year","Treatment"), direction="wide",sep=".")
#NMINMineral.stderr.Export<-reshape(NMINmineral.stderr, timevar="Month", v.names=c("NH4.kg.ha.month","NO3.kg.ha.month","ION.kg.ha.month"), idvar=c("Year","Treatment"), direction="wide",sep=".")

###Timeline Graph Setup-----------------------------
#This will generate some of the basic graphs we update every year; for the most part, this means the soil-related figures from Sarah Butler's 2012 Oecologia paper, but updated with the current data.

#Creates a dataframe containing monthly minerialization and standard errors.
NMINTimeline<-NMINFinal
NMINTimeline$Date<-as.Date(paste(NMINTimeline$Year,NMINTimeline$Month,"01",sep="/"),format="%Y/%m/%d")
NMINTimeline$IONPlusErr<-NMINTimeline$ION+NMINTimeline$StdErrION
NMINTimeline$IONMinusErr<-NMINTimeline$ION-NMINTimeline$StdErrION
NMINTimeline$NO3PlusErr<-NMINTimeline$NO3+NMINTimeline$StdErrNO3
NMINTimeline$NO3MinusErr<-NMINTimeline$NO3-NMINTimeline$StdErrNO3

#Sorts the dataframe by date and subsets it into heated and control dataframes. Note that order() is a tricky command, and needs to be used in a very specific manner or you risk scrambling your dataframe by decoupling the dates from their correct datapoints. Refer to pages 30 & 113 of The R Book by Michael Crawley for an explanation (we should have a copy in the RA office at Woods Hole).
ControlTimeline<-subset(NMINTimeline[order(NMINTimeline$Date),-c(2,3)], Treatment=="c")
HeatedTimeline<-subset(NMINTimeline[order(NMINTimeline$Date),-c(2,3)], Treatment=="h")

#By coercing the dates into a numeric vector, you get the number of days elapsed since January 1, 1970. We want to do this because in a few lines we'll want to calculate the average between two dates, and it works better this way. The other place we use it, we don't actually need the values, only the length of the vector.
Dates<-as.numeric(HeatedTimeline$Date)

###ION Timeline Graph-------------
#Defines the basic parameters of the Timeline figure and adds the heated plot data. Trims off the last datapoint as that is liable to not be a complete month.
plot(with(HeatedTimeline[-dim(HeatedTimeline)[1],], ION~Date), type="o", pch=16, mgp=c(2,0.7,0), las=1, ylim=c(0,40), xlim=c(Dates[1],Dates[length(Dates)]), bty="l", axes=F,
    main="Net Nitrogen Mineralization", ylab=expression(kg~N~ha^{-1}~mo^{-1}), xlab="")
    axis(side=1, at=Dates, labels=F)
    axis(side=2)
    legend(x="topleft",c("Control � StdErr","Heated � StdErr"),pch=c(1,16),lty=c(1,1),bty="n")

    #Adds another data series for the control plot and draws standard error bars (trimming as described above).
    points(with(ControlTimeline[-dim(ControlTimeline)[1],], ION~Date), type="o") 
    with(HeatedTimeline[-dim(HeatedTimeline)[1],], arrows(Date,IONMinusErr,Date,IONPlusErr,angle=90,code=3,
        length=0.05))
    with(ControlTimeline[-dim(ControlTimeline)[1],], arrows(Date,IONMinusErr,Date,IONPlusErr,angle=90,code=3,
        length=0.05)) 

    #Adds some formatting, and manually adds x-axis labels. The loop approximately reads "for every year, add a     light grey vertical dashed line between December and January of the next year, then paste the year as an axis label centered on June of that year." If for some reason you add dates to the *beginning* of the dataset, you will need to change some of the numbers in this loop.
    library(chron)
    for (i in 0:length(unique(years(HeatedTimeline$Date)))) {
      abline(v=mean(c(Dates[8+i*12],Dates[9+i*12])), col="lightgrey", lty=2) 
      mtext(unique(years(HeatedTimeline$Date))[i+1],at=Dates[3+i*12],side=1,line=0.8) #and adds the year
    }
    mtext("PreTrt",at=Dates[3],side=1,line=2)

###NO3 Timeline Graph-----------
#Creates the same graph, except for nitrification rates. Currently uses the same axes as the previous graph, for the sake of comparison. To look at this graph if isolation, you can change the y axis range by altering ylim() below.
plot(with(HeatedTimeline[-dim(HeatedTimeline)[1],], NO3~Date), type="o", pch=16, mgp=c(2,0.7,0), las=1, ylim=c(0,35), xlim=c(Dates[1],Dates[length(Dates)]), bty="l", axes=F,
     main="Net Nitrification", ylab=expression(kg~N~ha^{-1}~mo^{-1}), xlab="")
axis(side=1, at=Dates, labels=F)
axis(side=2)
legend(x="topleft",c("Control � StdErr","Heated � StdErr"),pch=c(1,16),lty=c(1,1),bty="n")

#Adds another data series for the control plot and draws standard error bars (trimming as described above).
points(with(ControlTimeline[-dim(ControlTimeline)[1],], NO3~Date), type="o") 
with(HeatedTimeline[-dim(HeatedTimeline)[1],], arrows(Date,NO3MinusErr,Date,NO3PlusErr,angle=90,code=3,
                                                      length=0.05))
with(ControlTimeline[-dim(ControlTimeline)[1],], arrows(Date,NO3MinusErr,Date,NO3PlusErr,angle=90,code=3,
                                                        length=0.05)) 

#Adds some formatting, and manually adds x-axis labels. The loop approximately reads "for every year, add a     light grey vertical dashed line between December and January of the next year, then paste the year as an axis label centered on June of that year." If for some reason you add dates to the *beginning* of the dataset, you will need to change some of the numbers in this loop.
library(chron)
for (i in 0:length(unique(years(HeatedTimeline$Date)))) {
  abline(v=mean(c(Dates[8+i*12],Dates[9+i*12])), col="lightgrey", lty=2) 
  mtext(unique(years(HeatedTimeline$Date))[i+1],at=Dates[3+i*12],side=1,line=0.8) #and adds the year
}
mtext("PreTrt",at=Dates[3],side=1,line=2)

###Quality Control Section------------------
#This conducts a series of tests to try and detect any errors in data entry, typos, mistakes, etc. that can throw off the analysis. This is NOT exhaustive, just a means to catch some of the more common/obvious ways things can go wrong.

#Any typos or inconsistient capitalization in the incubation column of the datafile will propogate a lot of NA's in your dataframes that shouldn't be there. The following line should only return two results: "initial" and "final".
levels(RawNMIN$Incubation)

#Checks for dates with mulitple entries in the final dataframes. 
duplicated(NMINFinal[,c(1:3)])
duplicated(NMINHorizons[,c(1:4)])
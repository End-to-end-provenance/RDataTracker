#Use this line to set your working directory. This will make all subsequent pathways much simpler.
#setwd("C:/MBL_HF/Harvard Forest/Barre Woods/Gas/Analyses/2014")
setwd("~/Desktop/BW Gas 2014")

###Setup-------
#This first section needs to be run every time. Each subsequent section (Warm/Calander years + Temperature/Temperatue & Moisture) can be run independently. However, be aware that as of the time of writing this script, the soil moisture model is very unstable and I would not trust it much.

#Imports the data and calculates TDR squared, which will be used in subsequent model fitting.a
BWCO2<-read.csv("R Input Files/BWCO2Data.csv")
BWCO2$TDR2<-BWCO2$TDR^2
BWCO2$LnCO2<-log(BWCO2$CO2)

#Check to make sure the data frame was created correctly. Even though we are treating it as a factor, you want year to be considered as an interger for this script (this allows for greater than/less than comparisons). If CO2 or Temp were interperted as factors, you probably have missing data points or typos in the input file. If you have extra variables with names like "X", "X.1", etc. you probably have extra (blank) columns in your .csv file.
str(BWCO2)

#Creates lists of warming years and calander years that will be used by subsequent sections. 
cyears<-levels(as.factor(BWCO2$Year))
wyears<-levels(as.factor(BWCO2$WarmYear))
wyearst<-wyears
wyearst[1]<-"Pre"
nyears<-length(cyears)

###Calander Year, Temperature Only-----
#Creates a pdf file that will store plots of fit diagnostics for you to review afterwards. By default it will overwrite a file by the same name, so change the file name and/or pathway if you don't want this to happen.
BW.CY.T.titles<-list(cyears,c("C.Int","C.Exp","C.Rsq","H.Int","H.Exp","H.Rsq"))
BW.CY.T.parameters<-matrix(numeric(0),nyears,6,dimnames=BW.CY.T.titles)
BW.CY.T.parameters

pdf("R Output Files/CY_T_fit_diagnostics.pdf", width=10, 
    height=6, onefile=T)

#Parameter calculation loop. The entire loop {all lines enclosed by brackets} needs to be executed at the same time. 
for (i in 1:nyears) {
  
  #Evaluates heated plot parameters
  H.subset<-subset(BWCO2,Year==cyears[i] & Treatment=="H")
  H.model<-lm(LnCO2 ~ CM4, data=H.subset)
  BW.CY.T.parameters[i,'H.Int']<-exp(H.model$coefficients[1])
  BW.CY.T.parameters[i,'H.Exp']<-H.model$coefficients[2]
  BW.CY.T.parameters[i,'H.Rsq']<-summary(H.model)$r.squared
  
  #Evaluates disturbance control plot parameters
  C.subset<-subset(BWCO2,Year==cyears[i] & Treatment=="C")
  C.model<-lm(LnCO2 ~ CM4, data=C.subset)
  BW.CY.T.parameters[i,'C.Int']<-exp(C.model$coefficients[1])
  BW.CY.T.parameters[i,'C.Exp']<-C.model$coefficients[2]
  BW.CY.T.parameters[i,'C.Rsq']<-summary(C.model)$r.squared
  
  #Generates plots for output to the pdf file
  par(mfrow=c(1,2))
  plot(with(C.subset, LnCO2~CM4), main = paste(cyears[i], "Linear Models"), col = 4, pch = 20,
       xlab=expression (Temperature (degree*C)),
       ylab=expression(LnCO[2]~Flux ~(mgC ~ m^{-2}* hr^{-1}))
  )
  points(with(H.subset, LnCO2~CM4), col = 2, pch = 20)
  curve((C.model$coefficients[2]*x + C.model$coefficients[1]), add = T, col = 4)
  curve((H.model$coefficients[2]*x +H.model$coefficients[1]), add = T, col = 2)
  mtext(paste("C r2=",round(summary(C.model)$r.squared,3)), side=3, adj = 0)
  mtext(paste("H r2=",round(summary(H.model)$r.squared,3)), side=3, adj = 1)
  plot(with(C.subset, CO2~CM4), main = paste(cyears[i], "Parameters"), col = 4, pch = 20,
       xlab=expression (Temperature (degree*C)),
       ylab=expression(CO[2]~Flux ~(mgC ~ m^{-2}* hr^{-1}))
  )
  points(with(H.subset, CO2~CM4), col = 2, pch = 20)
  curve(exp(C.model$coefficients[1])*exp(x*C.model$coefficients[2]), add = T, col = 4)
  curve(exp(H.model$coefficients[1])*exp(x*H.model$coefficients[2]), add = T, col = 2)
  par(mfrow=c(2,4))
  plot(H.model, main = paste("Heated", cyears[i]))
  plot(C.model, main = paste("Control", cyears[i]))
}

#Closes the pdf file, in the sense that further plots will be displayed rather than passed to the pdf. You still must close R Studio before you can open the file. Negative CO2 fluxes in the raw data file will produce the same error message here as they do when you initially calculate lnCO2. 
dev.off("CY_T_fit_diagnostics.pdf")

write.csv(BW.CY.T.parameters, "R Output Files/BW.CY.T.parameters.csv")

###Warming Year, Temperature Only--------
#Creates a pdf file that will store plots of fit diagnostics for you to review afterwards. By default it will overwrite a file by the same name, so change the file name and/or pathway if you don't want this to happen.
BW.WY.T.titles<-list(wyearst,c("C.Int","C.Exp","C.Rsq","H.Int","H.Exp","H.Rsq"))
BW.WY.T.parameters<-matrix(numeric(0),nyears,6,dimnames=BW.WY.T.titles)
BW.WY.T.parameters

pdf("R Output Files/WY_T_fit_diagnostics.pdf", width=10, 
    height=6, onefile=T)

#Parameter calculation loop. The entire loop {all lines enclosed by brackets} needs to be executed at the same time. 
for (i in 1:nyears) {
  
  #Evaluates heated plot parameters
  H.subset<-subset(BWCO2,WarmYear==wyears[i] & Treatment=="H")
  H.model<-lm(LnCO2 ~ CM4, data=H.subset)
  BW.WY.T.parameters[i,'H.Int']<-exp(H.model$coefficients[1])
  BW.WY.T.parameters[i,'H.Exp']<-H.model$coefficients[2]
  BW.WY.T.parameters[i,'H.Rsq']<-summary(H.model)$r.squared
  
  #Evaluates disturbance control plot parameters
  C.subset<-subset(BWCO2,WarmYear==wyears[i] & Treatment=="C")
  C.model<-lm(LnCO2 ~ CM4, data=C.subset)
  BW.WY.T.parameters[i,'C.Int']<-exp(C.model$coefficients[1])
  BW.WY.T.parameters[i,'C.Exp']<-C.model$coefficients[2]
  BW.WY.T.parameters[i,'C.Rsq']<-summary(C.model)$r.squared
  
  #Generates plots for output to the pdf file
  par(mfrow=c(1,2))
  plot(with(C.subset, LnCO2~CM4), main = paste("Year", wyearst[i], "Linear Models"), col = 4, pch = 20,
       xlab=expression (Temperature (degree*C)),
       ylab=expression(LnCO[2]~Flux ~(mgC ~ m^{-2}* hr^{-1}))
  )
  points(with(H.subset, LnCO2~CM4), col = 2, pch = 20)
  curve((C.model$coefficients[2]*x + C.model$coefficients[1]), add = T, col = 4)
  curve((H.model$coefficients[2]*x + H.model$coefficients[1]), add = T, col = 2)
  mtext(paste("C r2=",round(summary(C.model)$r.squared,3)), side=3, adj = 0)
  mtext(paste("H r2=",round(summary(H.model)$r.squared,3)), side=3, adj = 1)
  plot(with(C.subset, CO2~CM4), main = paste("Year", wyearst[i], "Parameters"), col = 4, pch = 20,
       xlab=expression (Temperature (degree*C)),
       ylab=expression(CO[2]~Flux ~(mgC ~ m^{-2}* hr^{-1}))
  )
  points(with(H.subset, CO2~CM4), col = 2, pch = 20)
  curve(exp(C.model$coefficients[1])*exp(x*C.model$coefficients[2]), add = T, col = 4)
  curve(exp(H.model$coefficients[1])*exp(x*H.model$coefficients[2]), add = T, col = 2)
  #par(mfrow=c(2,4))
  #plot(H.model, main = paste("Heated", "Year", wyearst[i]))
  #plot(C.model, main = paste("Control", "Year", wyearst[i]))
}

#Closes the pdf file, in the sense that further plots will be displayed rather than passed to the pdf. You still must close R Studio before you can open the file. Negative CO2 fluxes in the raw data file will produce the same error message here as they do when you initially calculate lnCO2. 
dev.off("WY_T_fit_diagnostics.pdf")

write.csv(BW.WY.T.parameters, "R Output Files/BW.WY.T.parameters.csv")

###Calander Year, Temperature & Moisture----------
BW.CY.TM.titles<-list(cyears,c("C.B0","C.B1","C.B2","C.B3","C.Rsq","H.B0","H.B1","H.B2","H.B3","H.Rsq"))
BW.CY.TM.parameters<-matrix(numeric(0),nyears,10,dimnames=BW.CY.TM.titles)
BW.CY.TM.parameters

#Sets some graphical paramters for the surface plots in the pdf file.
TempAxis<-seq(0,35,1)
TDRAxis<-seq(0,0.5,0.02)
TangEquationH<-function (t,m) exp(H.model$coefficients[1])*exp(t*H.model$coefficients[2])*exp(H.model$coefficients[3]*m + H.model$coefficients[4]*m^2)
TangEquationC<-function (t,m) exp(C.model$coefficients[1])*exp(t*C.model$coefficients[2])*exp(C.model$coefficients[3]*m + C.model$coefficients[4]*m^2)

pdf("R Output Files/CY_TM_fit_diagnostics.pdf", width=10, 
    height=6, onefile=T)

#Parameter calculation loop. This goes from 2:nyears instead of 1:nyears because we do not have TDR valuse for the pretreatment year, so the model won't work and the loop will fail.
for (i in 2:nyears) {
  
  #Evaluates heated plot parameters
  H.subset<-subset(BWCO2,Year==cyears[i] & Treatment=="H")
  H.model<-lm(LnCO2 ~ CM4 + TDR + TDR2, data=H.subset)
  BW.CY.TM.parameters[i,"H.B0"] <- exp(H.model$coefficients[1])
  BW.CY.TM.parameters[i,"H.B1"] <- H.model$coefficients[2]
  BW.CY.TM.parameters[i,"H.B2"] <- H.model$coefficients[3]
  BW.CY.TM.parameters[i,"H.B3"] <- H.model$coefficients[4]
  BW.CY.TM.parameters[i,"H.Rsq"] <- summary(H.model)$r.squared
  
  #Evaluates control plot parameters
  C.subset<-subset(BWCO2,Year==cyears[i] & Treatment=="C")
  C.model<-lm(LnCO2 ~ CM4 + TDR + TDR2, data=C.subset)
  BW.CY.TM.parameters[i,"C.B0"] <- exp(C.model$coefficients[1])
  BW.CY.TM.parameters[i,"C.B1"] <- C.model$coefficients[2]
  BW.CY.TM.parameters[i,"C.B2"] <- C.model$coefficients[3]
  BW.CY.TM.parameters[i,"C.B3"] <- C.model$coefficients[4]
  BW.CY.TM.parameters[i,"C.Rsq"] <- summary(C.model)$r.squared

  #Generates plots for output to the pdf file
  par(mfrow=c(1,2))
  HeatedSurface<-outer(TempAxis,TDRAxis,TangEquationH)
  ControlSurface<-outer(TempAxis,TDRAxis,TangEquationC)
  persp(TempAxis,TDRAxis,HeatedSurface,theta=-45, phi=30, xlab="Temperature (C)", ylab="Moisture (VWC)", 
        zlab="CO2 Flux", d=5, col="indianred2", shade=0.8, expand=0.65, ticktype="detailed", 
        main = paste(cyears[i], "Heated Parameters"))
  persp(TempAxis,TDRAxis,ControlSurface,theta=-45, phi=30, xlab="Temperature (C)", ylab="Moisture (VWC)", 
        zlab="CO2 Flux", d=5, col="lightblue", shade=0.8, expand=0.65, ticktype="detailed", 
        main = paste(cyears[i], "Control Parameters"))
  #par(mfrow=c(2,4))
  #plot(H.model, main=paste(cyears[i], "Heated"))
  #plot(C.model, main=paste(cyears[i], "Control"))
}

dev.off("CY_TM_fit_diagnostics.pdf")

write.csv(BW.CY.TM.parameters, "R Output Files/BW.CY.TM.parameters.csv")

###Warming Year, Temperature & Moisture--------
BW.WY.TM.titles<-list(wyearst,c("C.B0","C.B1","C.B2","C.B3","C.Rsq","H.B0","H.B1","H.B2","H.B3","H.Rsq"))
BW.WY.TM.parameters<-matrix(numeric(0),nyears,10,dimnames=BW.WY.TM.titles)
BW.WY.TM.parameters

#Sets some graphical paramters for the surface plots in the pdf file.
TempAxis<-seq(0,35,1)
TDRAxis<-seq(0,0.5,0.02)
TangEquationH<-function (t,m) exp(H.model$coefficients[1])*exp(t*H.model$coefficients[2])*exp(H.model$coefficients[3]*m + H.model$coefficients[4]*m^2)
TangEquationC<-function (t,m) exp(C.model$coefficients[1])*exp(t*C.model$coefficients[2])*exp(C.model$coefficients[3]*m + C.model$coefficients[4]*m^2)

pdf("R Output Files/WY_TM_fit_diagnostics.pdf", width=10, 
    height=6, onefile=T)

#Parameter calculation loop. This goes from 2:nyears instead of 1:nyears because we do not have TDR valuse for the pretreatment year, so the model won't work and the loop will fail.
for (i in 2:nyears) {
  
  #Evaluates heated plot parameters
  H.subset<-subset(BWCO2,WarmYear==wyears[i] & Treatment=="H")
  H.model<-lm(LnCO2 ~ CM4 + TDR + TDR2, data=H.subset)
  BW.WY.TM.parameters[i,"H.B0"] <- exp(H.model$coefficients[1])
  BW.WY.TM.parameters[i,"H.B1"] <- H.model$coefficients[2]
  BW.WY.TM.parameters[i,"H.B2"] <- H.model$coefficients[3]
  BW.WY.TM.parameters[i,"H.B3"] <- H.model$coefficients[4]
  BW.WY.TM.parameters[i,"H.Rsq"] <- summary(H.model)$r.squared
  
  #Evaluates control plot parameters
  C.subset<-subset(BWCO2,WarmYear==wyears[i] & Treatment=="C")
  C.model<-lm(LnCO2 ~ CM4 + TDR + TDR2, data=C.subset)
  BW.WY.TM.parameters[i,"C.B0"] <- exp(C.model$coefficients[1])
  BW.WY.TM.parameters[i,"C.B1"] <- C.model$coefficients[2]
  BW.WY.TM.parameters[i,"C.B2"] <- C.model$coefficients[3]
  BW.WY.TM.parameters[i,"C.B3"] <- C.model$coefficients[4]
  BW.WY.TM.parameters[i,"C.Rsq"] <- summary(C.model)$r.squared
  
  #Generates plots for output to the pdf file
  par(mfrow=c(1,2))
  HeatedSurface<-outer(TempAxis,TDRAxis,TangEquationH)
  ControlSurface<-outer(TempAxis,TDRAxis,TangEquationC)
  persp(TempAxis,TDRAxis,HeatedSurface,theta=-45, phi=30, xlab="Temperature (C)", ylab="Moisture (VWC)", 
        zlab="CO2 Flux", d=5, col="indianred2", shade=0.8, expand=0.65, ticktype="detailed", 
        main = paste(cyears[i], "Heated Parameters"))
  persp(TempAxis,TDRAxis,ControlSurface,theta=-45, phi=30, xlab="Temperature (C)", ylab="Moisture (VWC)", 
        zlab="CO2 Flux", d=5, col="lightblue", shade=0.8, expand=0.65, ticktype="detailed", 
        main = paste(cyears[i], "Control Parameters"))
  #par(mfrow=c(2,4))
  #plot(H.model, main=paste("Year", cyears[i], "Heated"))
  #plot(C.model, main=paste("Year", cyears[i], "Control"))
}

dev.off("WY_TM_fit_diagnostics.pdf")

write.csv(BW.WY.TM.parameters, "R Output Files/BW.WY.TM.parameters.csv")
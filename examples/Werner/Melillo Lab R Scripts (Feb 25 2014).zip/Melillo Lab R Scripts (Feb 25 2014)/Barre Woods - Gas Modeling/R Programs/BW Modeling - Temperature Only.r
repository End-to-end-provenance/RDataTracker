#Note that this script uses many of the same object names as the prospect hill gas modeling script, so if you have been running that script you should save anything you want to keep and then clear your workspace of objects before starting this one. The following command will clear your workspace.
rm(list=ls())

#I reccomend setting your working directory to the appropriate year's folder. This will make all your pathways more managable. 
setwd("C:/MBL_HF/Harvard Forest/Barre Woods/Gas/Analyses/2014")
#setwd("~/Desktop/BW Gas 2014")

Logger<-read.csv("R Input Files/BWTempData.csv")

###Temperature Only-------
Parameters<-read.csv("R Output Files/BW.CY.T.parameters.csv")
names(Parameters)[1]<-"Year"

#Due to poor parameter fit in 2010, we substitute the 2009 parameters for that year.
Parameters2<-Parameters
Parameters2[9,2]<-Parameters[8,2]
Parameters2[9,3]<-Parameters[8,3]
Parameters2[9,4]<-Parameters[8,4]
Parameters2[9,5]<-Parameters[8,5]
Parameters2[9,6]<-Parameters[8,6]
Parameters2[9,7]<-Parameters[8,7]

#Merges temperature data and parameter data into a single dataframe.
CO2.g.m2<-merge(Logger,Parameters2, by="Year",sort=T)

#Subsets out data prior to 12:00 on July 22nd 2008, when we switched from recording temperature every six hours to recording temperature hourly. | is R's "or" logical operator.
CO2.g.m2.qtr<-subset(CO2.g.m2, Year < 2008 | 
                               Year == 2008 & Day < 204 | 
                               Year == 2008 & Day == 204 & Time < 1200)
CO2.g.m2.hr<-subset(CO2.g.m2, Year > 2008 | 
                              Year == 2008 & Day > 204 | 
                              Year == 2008 & Day == 204 & Time >= 1200)

#Calculates emissions per quarter-day for data prior to the split.
CO2.g.m2.qtr$H3CO2<-with(CO2.g.m2.qtr, H.Int*exp(H3T*H.Exp)*6/1000)
CO2.g.m2.qtr$H6CO2<-with(CO2.g.m2.qtr, H.Int*exp(H6T*H.Exp)*6/1000)
CO2.g.m2.qtr$H12CO2<-with(CO2.g.m2.qtr, H.Int*exp(H12T*H.Exp)*6/1000)
CO2.g.m2.qtr$H14CO2<-with(CO2.g.m2.qtr, H.Int*exp(H14T*H.Exp)*6/1000)
CO2.g.m2.qtr$H16CO2<-with(CO2.g.m2.qtr, H.Int*exp(H16T*H.Exp)*6/1000)
CO2.g.m2.qtr$H25CO2<-with(CO2.g.m2.qtr, H.Int*exp(H25T*H.Exp)*6/1000)
CO2.g.m2.qtr$H27CO2<-with(CO2.g.m2.qtr, H.Int*exp(H27T*H.Exp)*6/1000)
CO2.g.m2.qtr$H34CO2<-with(CO2.g.m2.qtr, H.Int*exp(H34T*H.Exp)*6/1000)
CO2.g.m2.qtr$CtlCO2<-with(CO2.g.m2.qtr, C.Int*exp(CavgT*C.Exp)*6/1000)

#Calculates emissions per hour for data after the split.
CO2.g.m2.hr$H3CO2<-with(CO2.g.m2.hr, H.Int*exp(H3T*H.Exp)/1000)
CO2.g.m2.hr$H6CO2<-with(CO2.g.m2.hr, H.Int*exp(H6T*H.Exp)/1000)
CO2.g.m2.hr$H12CO2<-with(CO2.g.m2.hr, H.Int*exp(H12T*H.Exp)/1000)
CO2.g.m2.hr$H14CO2<-with(CO2.g.m2.hr, H.Int*exp(H14T*H.Exp)/1000)
CO2.g.m2.hr$H16CO2<-with(CO2.g.m2.hr, H.Int*exp(H16T*H.Exp)/1000)
CO2.g.m2.hr$H25CO2<-with(CO2.g.m2.hr, H.Int*exp(H25T*H.Exp)/1000)
CO2.g.m2.hr$H27CO2<-with(CO2.g.m2.hr, H.Int*exp(H27T*H.Exp)/1000)
CO2.g.m2.hr$H34CO2<-with(CO2.g.m2.hr, H.Int*exp(H34T*H.Exp)/1000)
CO2.g.m2.hr$CtlCO2<-with(CO2.g.m2.hr, C.Int*exp(CavgT*C.Exp)/1000)

#Combines the two dataframes. NOTE: THE DATA IN THIS DATAFRAME FROM BEFORE AND AFTER THE SPLIT ARE NOT COMPRABLE; DATA BEFORE THE SPLIT ARE STILL QUATER DAY FLUXES AND DATA AFTER THE SPLIT ARE HOURLY FLUXES
CO2.g.m2.combine<-rbind(CO2.g.m2.qtr, CO2.g.m2.hr)

#Calculates daily emissions (Now the before-and-after-split data is comprable)
CO2.g.m2.day<-aggregate(CO2.g.m2.combine[,c("H3CO2","H6CO2","H12CO2","H14CO2","H16CO2","H25CO2","H27CO2","H34CO2","CtlCO2")],CO2.g.m2.combine[,c("Day","Year","Warmyear")], FUN=sum, na.rm=T)

#Uncomment this line for a daily fluxes.
#write.csv(CO2.g.m2.day, "R Output Files/DailyFluxes.csv")

#Calculates monthly fluxes
library(chron)
CO2.g.m2.combine$Month<-as.factor(month.day.year(CO2.g.m2.combine$Day)$month)
CO2.g.m2.month<-aggregate(CO2.g.m2.combine[,c("H3CO2","H6CO2","H12CO2","H14CO2","H16CO2","H25CO2","H27CO2","H34CO2","CtlCO2")],CO2.g.m2.combine[,c("Month","Year","Warmyear")], FUN=sum, na.rm=T)

#Calculates calander year fluxes
CO2.g.m2.calyear<-aggregate(CO2.g.m2.combine[,c("H3CO2","H6CO2","H12CO2","H14CO2","H16CO2","H25CO2","H27CO2","H34CO2","CtlCO2")], by=list(CO2.g.m2.combine$Year), FUN=sum, na.rm=T)
names(CO2.g.m2.calyear)[1]<-"Year"
write.csv(CO2.g.m2.calyear, "R Output Files/CalYearFluxes.csv")

#Calculates warming year fluxes
CO2.g.m2.warmyear<-aggregate(CO2.g.m2.combine[,c("H3CO2","H6CO2","H12CO2","H14CO2","H16CO2","H25CO2","H27CO2","H34CO2","CtlCO2")], by=list(CO2.g.m2.combine$Warmyear), FUN=sum, na.rm=T)
names(CO2.g.m2.warmyear)[1]<-"WarmYear"
write.csv(CO2.g.m2.warmyear, "R Output Files/WarmYearFluxes.csv")
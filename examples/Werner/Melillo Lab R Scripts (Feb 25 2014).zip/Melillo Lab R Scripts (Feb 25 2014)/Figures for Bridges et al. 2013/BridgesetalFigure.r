#NOTE: To preserve special characters in axis labels, this file must be saved with encoding. GB18030 works - there may be other encoding formats that also work.

#Adjust the pathway according to where you have your files.
setwd("C:/MBL_HF/Harvard Forest/Barre Woods/Vegetation/Canopy Trees/Foliage/Summary_files/Figures for Bridges et al. 2013")

###Execute these lines first. AFterward, each section headed by ### can be executed independently.
library(plotrix)
stderr <- function(x) sd(x, na.rm=T)/sqrt(length(na.omit(x))) 
par(mar=(c(5,5,4,2) + 0.1))
CNData<-read.csv("GreenLeafCN2013.csv")

Means<-aggregate(CNData[,c("PctN.PTCorr","N15.PTCorr")], CNData[,c("Year","Species","Treatment")], FUN=mean, na.rm=T)
Errors<-aggregate(CNData[,c("PctN.PTCorr","N15.PTCorr")], CNData[,c("Year","Species","Treatment")], FUN=stderr)
Means$N15.PlusErr<-Means$N15.PTCorr+Errors$N15.PTCorr
Means$N15.MinusErr<-Means$N15.PTCorr-Errors$N15.PTCorr
Means$PctN.PlusErr<-Means$PctN.PTCorr+Errors$PctN.PTCorr
Means$PctN.MinusErr<-Means$PctN.PTCorr-Errors$PctN.PTCorr


ACRU15N<-subset(Means, Species=="ACRU" & is.nan(N15.PTCorr)==F)
QURU15N<-subset(Means, (Species=="QURU" | Species=="QUVE") & is.nan(N15.PTCorr)==F)
ACRUPctN<-subset(Means, Species=="ACRU" & is.nan(PctN.PTCorr)==F)
QURUPctN<-subset(Means, (Species=="QURU" | Species=="QUVE") & is.nan(PctN.PTCorr)==F)

###ACRU 15N
plot(subset(ACRU15N$N15.PTCorr, ACRU15N$Treatment=="C"), type="l", ylim=c(-5,0), axes=F, lwd=2, col="dodgerblue2", xlab="Year", ylab=expression(paste(delta^{15}, "N (\u2030 vs. air)")), main=expression(paste("Foliar "^{15}, "N - ACRU")))
arrows(x0=c(1:6), x1=c(1:6), y0=ACRU15N$N15.MinusErr[c(1:6)], y1=ACRU15N$N15.PlusErr[c(1:6)], angle=90, code=3, length=0.05)
points(subset(ACRU15N$N15.PTCorr, ACRU15N$Treatment=="H"), type="l", lwd=2, col="brown2")
arrows(x0=c(1:6), x1=c(1:6), y0=ACRU15N$N15.MinusErr[c(7:12)], y1=ACRU15N$N15.PlusErr[c(7:12)], angle=90, code=3, length=0.05)
axis(side=1, at=c(1:6),labels=c("2002","2007","2009","2010","2011","2012"), lwd=1)
abline(h=-5.2, lwd=1)
axis.break(axis=1, breakpos=1.5)
axis.break(axis=1, breakpos=2.5)
axis(side=2, lwd=1)
abline(v=0.8, lwd=1)
legend(x=0.8, y=0.2, legend=c("Control","Heated"), lwd=c(2,2), col=c("dodgerblue2","brown2"), bty="n")

###QURU 15N
plot(subset(QURU15N$N15.PTCorr, QURU15N$Treatment=="C"), type="l", ylim=c(-5,0), axes=F, lwd=2, col="dodgerblue2", xlab="Year", ylab=expression(paste(delta^{15}, "N (\u2030 vs. air)")), main=expression(paste("Foliar "^{15}, "N - QUSP")))
arrows(x0=c(1:6), x1=c(1:6), y0=QURU15N$N15.MinusErr[c(1:6)], y1=QURU15N$N15.PlusErr[c(1:6)], angle=90, code=3, length=0.05)
points(subset(QURU15N$N15.PTCorr, QURU15N$Treatment=="H"), type="l", lwd=2, col="brown2")
arrows(x0=c(1:6), x1=c(1:6), y0=QURU15N$N15.MinusErr[c(7:12)], y1=QURU15N$N15.PlusErr[c(7:12)], angle=90, code=3, length=0.05)
axis(side=1, at=c(1:6),labels=c("2002","2007","2009","2010","2011","2012"), lwd=1)
abline(h=-5.2, lwd=1)
axis.break(axis=1, breakpos=1.5)
axis.break(axis=1, breakpos=2.5)
axis(side=2, lwd=1)
abline(v=0.8, lwd=1)
legend(x=0.8, y=0.2, legend=c("Control","Heated"), lwd=c(2,2), col=c("dodgerblue2","brown2"), bty="n")

###ACRU %N
par(mar=(c(5,5,4,2) + 0.1))
plot(subset(ACRUPctN$PctN.PTCorr, ACRUPctN$Treatment=="C"), type="l", ylim=c(0,3), axes=F, lwd=2, col="dodgerblue2", xlab="Year", ylab="% N", main="Foliar % N - ACRU")
arrows(x0=c(1:11), x1=c(1:11), y0=ACRUPctN$PctN.MinusErr[c(1:11)], y1=ACRUPctN$PctN.PlusErr[c(1:11)], angle=90, code=3, length=0.05)
points(subset(ACRUPctN$PctN.PTCorr, ACRUPctN$Treatment=="H"), type="l", lwd=2, col="brown2")
arrows(x0=c(1:11), x1=c(1:11), y0=ACRUPctN$PctN.MinusErr[c(12:22)], y1=ACRUPctN$PctN.PlusErr[c(12:22)], angle=90, code=3, length=0.05)
axis(side=1, at=c(1:11),labels=c("PreTrt","Year 1","Year 2","Year 3","Year 4","Year 5","Year 6","Year 7", "Year 8","Year 9","Year 10"), lwd=1, las=2)
abline(h=-0.12, lwd=1)

axis(side=2, lwd=1)
abline(v=0.6, lwd=1)
legend(x=0.8, y=3, legend=c("Control","Heated"), lwd=c(2,2), col=c("dodgerblue2","brown2"), bty="n")

###QURU %N
plot(subset(QURUPctN$PctN.PTCorr, QURUPctN$Treatment=="C"), type="l", ylim=c(0,3), axes=F, lwd=2, col="dodgerblue2", xlab="Year", ylab="% N", main="Foliar % N - QUSP")
arrows(x0=c(1:11), x1=c(1:11), y0=QURUPctN$PctN.MinusErr[c(1:11)], y1=QURUPctN$PctN.PlusErr[c(1:11)], angle=90, code=3, length=0.05)
points(subset(QURUPctN$PctN.PTCorr, QURUPctN$Treatment=="H"), type="l", lwd=2, col="brown2")
arrows(x0=c(1:11), x1=c(1:11), y0=QURUPctN$PctN.MinusErr[c(12:22)], y1=QURUPctN$PctN.PlusErr[c(12:22)], angle=90, code=3, length=0.05)
axis(side=1, at=c(1:11),labels=c(2002:2012), lwd=1)
abline(h=-0.12, lwd=1)
axis(side=2, lwd=1)
abline(v=0.6, lwd=1)
legend(x=0.8, y=3, legend=c("Control","Heated"), lwd=c(2,2), col=c("dodgerblue2","brown2"), bty="n")


###Boxplot for 15N.
ACRUSubset<-subset(CNData, Species=="ACRU" & is.na(N15.PTCorr)==F)
QURUSubset<-subset(CNData, Species=="QURU" & is.na(N15.PTCorr)==F)

par(mfrow=c(1,2))
boxplot(N15.PTCorr~Treatment*Year, data=ACRUSubset, col=c(rgb(0,0,1,1/4),rgb(1,0,0,1/4)), ylab = "�6�215N  (�� vs. air)", axes=F, ylim=c(-6,1), main="ACRU")
axis(side=1, at=c(1.5,3.5,5.5,7.5,9.5,11.5),labels=c("2002","2007","2009","2010","2011","2012"), las=2)
axis.break(axis=1, breakpos=2.5)
axis.break(axis=1, breakpos=4.5)
axis(side=2)
legend(x=0.5, y=1.25, legend=c("Control","Heated"), fill=c(rgb(0,0,1,1/4),rgb(1,0,0,1/4)), bty="n")
boxplot(N15.PTCorr~Treatment*Year, data=QURUSubset, col=c(rgb(0,0,1,1/4),rgb(1,0,0,1/4)), ylab = "�6�215N  (�� vs. air)", axes=F, ylim=c(-6,1), main="QURU")
axis(side=1, at=c(1.5,3.5,5.5,7.5,9.5,11.5),labels=c("2002","2007","2009","2010","2011","2012"), las=2)
axis.break(axis=1, breakpos=2.5)
axis.break(axis=1, breakpos=4.5)
axis(side=2)

###Investigation of the supposedly "tight" correlation between air and soil temperature.
setwd("C:/MBL_HF/Harvard Forest/Weather/Fisher data")
FisherData<-read.csv("FisherHourly130426.csv")
FisherModel<-lm(AirT~S10T, data=FisherData)
summary(FisherModel)
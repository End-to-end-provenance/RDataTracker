#This script calculates woody growth at Barre Woods from the dendrology data. The CaliperData file contains all dendrology measurements taken at Barre Woods; trees that grew into the size class we measure are incorporated throughout the dataset. The TreeData sheet is currently only used for the alive/dead column, but it also contains the position and health data we've collected. 


###Setup and Data Import---------------------------------------------------
#I reccomend setting your working directory to this year's data analysis folder. This will make all your pathways much more managable: 
setwd("C:/MBL_HF/Harvard Forest/Barre Woods/Vegetation/Canopy Trees/dendrology/data analysis/2014")

#What sampling dates do you want to use for yearly dendrology calculations? This list will need to be updated every year. It is important to list these dates in chronological order.
YearlyDates<-c(20603,30506,40510,50510,60418,70503,80520,90413,100415,110502,120416,130418,131105)
YearlyNames<-c("InitialBM","PreTrt","Year 1","Year 2","Year 3","Year 4","Year 5","Year 6","Year 7","Year 8","Year 9","Year 10","Year 11")

#Same as the lines above, but for the supplementary control plots. Note that we do not have 2008 data, but SCYearlyNames names must still match with the YearlyNames, so I haven't changed "Year 7" to something like "Years 6-7".
SCYearlyDates<-c(61031,70930,91101,110501,120501,130425)
SCYearlyNames<-c("Year 4","Year 5", "Year 7", "Year 8", "Year 9", "Year 10")

#Imports caliper data, tree data and parameters for allometric equations. If you add any new species to the list (unlikely, but it's not inconcievable that some of the understory PRSE could grow to 5 cm dbh), you'll need to add paramters for them to the Allometry file.
Caliper<-read.csv("R Input Files/BWCaliperData.csv")
Caliper<-subset(Caliper, fdate >= idate)
Trees<-read.csv("R Input Files/BWTreeData.csv")
Allometry<-read.csv("R Input Files/BWAllometricParameters.csv")
SuppControl<-read.csv("R Input Files/SupplementalControlPlots.csv")

###Caliper Measurements to Woody Biomass Calculations ----------------------
#Converts caliper readings from mm to cm.

Caliper$icaliper<-Caliper$icaliper/10
Caliper$fcaliper<-Caliper$fcaliper/10

#Converts caliper readings from chord lengths to arc lengths.
Caliper$ifraction<-Caliper$icaliper/Caliper$iDBH
Caliper$ffraction<-Caliper$fcaliper/Caliper$iDBH
Caliper$iarc<-((2*asin(Caliper$ifraction))*(Caliper$iDBH/2)) 
Caliper$farc<-((2*asin(Caliper$ffraction))*(Caliper$iDBH/2))

#Calculates initial and final basal area (BA) and circumference, as well as the difference (final-initial) in arc lengths for each measurement date. Basal area calcualtions do not appear to be used for anything, but were in the old script, so I wrote them into this one.
Caliper$iBA<-pi*(Caliper$iDBH/2)^2
Caliper$iCircumference<-pi*Caliper$iDBH
Caliper$darc<-with(Caliper, farc-iarc)
Caliper$fCircumference<-with(Caliper, iCircumference + darc)
Caliper$fDBH<-Caliper$fCircumference/pi
Caliper$fBA<-pi*(Caliper$fDBH/2)^2

#This line is here for scripting troubleshooting purposes. Feel free to ignore it otherwise.
#write.csv(Caliper, "R Output Files/Caliper.csv", row.names=F)

#Calculates initial and final basal area (BA) for supplementary control plot trees.
SuppControl$iBA<-pi*(SuppControl$iDBH/2)^2
SuppControl$fBA<-pi*(SuppControl$fDBH/2)^2

#Trims columns no longer needed from the Caliper dataframe and merges allometric parameters (from Jenkins et al. 2003) into it. You might notice that the MainDendro dataframe is shorter than the Caliper dataframe - this is because there are three trees in the dataset that have no species designation (species=NA). This means they cannot be assigned allometric parameters, and therefore cannot be analyzed. To analyze them anyway, you would need to add an NA line to the Allomery input file and figure out what you would want to use for parameters for an unknown species. You could also try adding "all.x=T" to the command.
MainDendro<-merge(Caliper[,c(1:5,7,17,13,18)],Allometry, by="Species")
SuppDendro<-merge(SuppControl,Allometry, by="Species")
Dendro<-rbind(MainDendro,SuppDendro)

#Calculates initial and final aboveground biomass.
Dendro$iAboveBiomass<-with(Dendro, exp(aB0 + (aB1*log(iDBH))))
Dendro$fAboveBiomass<-with(Dendro, exp(aB0 + (aB1*log(fDBH))))

#Calculates ratio of coarse root biomass to aboveground biomass, root biomass, and total biomass.
Dendro$iRootRatio<-with(Dendro, exp(rB0 + (rB1/iDBH)))
Dendro$fRootRatio<-with(Dendro, exp(rB0 + (rB1/fDBH)))
Dendro$iRoot<-with(Dendro, iRootRatio*iAboveBiomass)
Dendro$fRoot<-with(Dendro, fRootRatio*fAboveBiomass)
Dendro$iTotalBiomass<-with(Dendro, iAboveBiomass+iRoot)
Dendro$fTotalBiomass<-with(Dendro, fAboveBiomass+fRoot)

#Calculates the foliage biomass and subtracts it from total biomass to get woody biomass.
Dendro$iFoliageRatio<-with(Dendro, exp(foB0 + (foB1/iDBH)))
Dendro$fFoliageRatio<-with(Dendro, exp(foB0 + (foB1/fDBH)))
Dendro$iFoliage<-with(Dendro, iFoliageRatio*iAboveBiomass)
Dendro$fFoliage<-with(Dendro, fFoliageRatio*fAboveBiomass)
Dendro$iWoodyBiomass<-with(Dendro, iTotalBiomass - iFoliage)
Dendro$fWoodyBiomass<-with(Dendro, fTotalBiomass - fFoliage)

#This line is here for scripting troubleshooting purposes. Feel free to ignore it otherwise.
#write.csv(PreYearlyDendro, "R Output Files/PreYearlyDendro.csv", row.names=F)


### Metadata Merge, Woody Increment, Percent Growth -------------------
#Merges the biomass data into the factor data for each tree. Creates columns for woody increment and percent growth to recieve values from the following loop.
PreYearlyDendro<-subset(Dendro[,c("Species","Tree","Plot","fdate","fWoodyBiomass")], (fdate %in% YearlyDates | fdate %in% SCYearlyDates))
YearlyDendro<-merge(PreYearlyDendro, Trees[,c("Tree","Plot","Species","DeathDate")], by=c("Tree","Plot","Species"))
YearlyDendro$WoodyIncrement<-NA
YearlyDendro$PctGrowth<-NA
YearlyDendro$Year<-ifelse(YearlyDendro$fdate %in% YearlyDates, #Logical test to evaluate
                          YearlyNames[match(YearlyDendro$fdate,YearlyDates)], #Run if evaluation=true
                          SCYearlyNames[match(YearlyDendro$fdate,SCYearlyDates)]) #Run if evaluation=false

#Calculates woody increment and percent growth for each entry. Woody Increment & Percent Growth are calculated over the year that ended on fdate of the entry (so both are 0/NA for 20603, since we would need measurements from 2001 to calculat those). 
for (i in 1:dim(YearlyDendro)[1]) {
  TreeID<-YearlyDendro$Tree[i]
  fDate<-YearlyDendro$fdate[i]
  if (as.numeric(TreeID) < 1000) idate<-YearlyDates[match(fDate,YearlyDates)-1]
  else idate<-SCYearlyDates[match(fDate,SCYearlyDates)-1]
  fBiomass<-YearlyDendro$fWoodyBiomass[i]
  iBiomass<-as.numeric(subset(YearlyDendro, Tree==TreeID & fdate==idate)$fWoodyBiomass)
  YearlyDendro[i,"WoodyIncrement"]<-if(length(fBiomass-iBiomass)!=0) fBiomass-iBiomass else NA
  YearlyDendro[i,"PctGrowth"]<-if(length((fBiomass-iBiomass)/iBiomass)!=0) (fBiomass-iBiomass)/iBiomass else NA
}

#This file also goes in a tab in the results excel file. It's the same information as AllTrees, but in long format, which is more pivot table friendly.
write.csv(YearlyDendro, "R Output Files/YearlyDendroRound.csv", row.names=F)

###Individual Tree to Plot Aggregation--------------
#Calculates the total live woody biomass, woody increment, and average percent growth in each plot at each yearly sampling date.
Biomass<-aggregate(YearlyDendro[,c("fWoodyBiomass","WoodyIncrement")],YearlyDendro[,c("fdate","Plot")], FUN=sum, na.rm=T); names(Biomass)[3]<-"LiveWoodyBiomass"
PctGrowth<-aggregate(YearlyDendro[,"PctGrowth"],YearlyDendro[,c("fdate","Plot")], FUN=mean, na.rm=T); names(PctGrowth)[3]<- "PctGrowth"
PlotsLive<-cbind(Biomass,PctGrowth[3])

###Dead Pool Calculations-----------------
#Creates a dataframe of all the trees that have died since the beginning of the experiment.
AllDead<-subset(YearlyDendro, is.na(DeathDate)==F)

#Simplifies the AllDead dataframe, and then summarizes it by year and plot. Note that year-plot combinations with no mortality do not get a line in this dataframe, so it will not be the same length as the rest of the plot-year summary dataframes.
AllDeadFinalBM<-aggregate(AllDead[,"fWoodyBiomass"], AllDead[,c("Tree","Plot","Species","DeathDate")], FUN=max, na.rm=T)
names(AllDeadFinalBM)[5]<-"fWoodyBiomass"

#For each death date, looks up the corresponding yearly sampling date we're using (rounding down initially, then moving one date later in the list, so all dates between 20603 & 30506 would get 30506). The -1 following DeathDates fixes an issue I initially had when a death date was equal to a yearly sampling date.
AllDeadFinalBM$DeathYear<-YearlyDates[findInterval(AllDeadFinalBM$DeathDate-1,YearlyDates)+1]
DeadPoolInputs<-aggregate(AllDeadFinalBM["fWoodyBiomass"],AllDeadFinalBM[,c("DeathYear","Plot")], FUN=sum)

#Corrects dead pool (main) control plot inputs for pretreatment differences in biomass between the heated and control plots. Since this simply represents a tranfer of woody biomass from a live to a dead pool, biomass in each pool should use the same correction factor.
DeadPoolInputs$fWoodyBiomassPTCorr<-with(DeadPoolInputs, ifelse(Plot=="C",fWoodyBiomass*BMPreTrtCorr,fWoodyBiomass))

#Creates the Dead Pool dataframe to recieve dead biomass values. Using the Biomass frame to set this up is somewhat arbitrary, but it is important that the dates are still in order, which they won't be in a dataframe that has been subject to any merge() functions. Even using the "sort=T" argument in merge still won't get it back in quite the right order.
DeadPool<-Biomass[1:3]
DeadPool$Year<-YearlyDates[findInterval(DeadPool$fdate,YearlyDates)]
names(DeadPool)[3]<-"DeadPool"
DeadPool$DeadPool<-NA
DeadPool$DeadPoolInputs<-NA

#Calculates the dead biomass pool for each year. This is not a true coarse woody debries pool, as we do not have initial CWD data. This pool only encompasses the biomass of trees that have died since the initiation of the experiment - without this, their stored carbon would simply dissappear from our analysis as soon as they died. The pools are set to zero for the pretreatment year. Each subsequent year recieves the biomass of all the trees that died during the previous year. Additionally, 94% of each year's dead pool carries over to the next year. This is equivilant to assuming that after dying, a tree decomposes at a rate of 6% of its mass per year (Barford et al. 2001).
for (i in 1:dim(DeadPool)[1]) {
  Trt<-DeadPool[i,"Plot"]
  Date<-DeadPool[i,"Year"]
  FirstDate<-if (Trt %in% c("C","H","B","Bh")) 20603 else 60418
  DeadPool[i,3]<-ifelse(dim(subset(DeadPoolInputs, DeathYear==Date & Plot==Trt))[1]!=0,
                          as.numeric(subset(DeadPoolInputs, DeathYear==Date & Plot==Trt)[3]),
                          0) + if (Date!=FirstDate) DeadPool[i-1,3]*0.94 else 0
  DeadPool[i,5]<-ifelse(dim(subset(DeadPoolInputs, DeathYear==Date & Plot==Trt))[1]!=0,
                        as.numeric(subset(DeadPoolInputs, DeathYear==Date & Plot==Trt)[3]),0)
}

#Creates a new dataframe with both the live and dead biomass, representing the total amount of carbon in the plots. Then removes the buffer zone trees, as subsequent calculations will convert these values into units of area, and we have not currently surveyed the buffer zone to determine its area.
PrePlotsCarbon<-merge(PlotsLive,DeadPool[,-4], by=c("Plot","fdate"))
PlotsCarbon<-subset(PrePlotsCarbon, Plot!="B" & Plot!="BH")

###Pretreatment Corrections-------------------
#Calculates pretreatment correction factors based on the initial diffrence in biomass between the heated and control plot. BM=Biomass, WI=Woody Increment, PG = Percent Growth. 
BMPreTrtH<-as.numeric(subset(PlotsLive, fdate==20603 & Plot=="H")$LiveWoodyBiomass)
BMPreTrtC<-as.numeric(subset(PlotsLive, fdate==20603 & Plot=="C")$LiveWoodyBiomass)
BMPreTrtCorr<-BMPreTrtH/BMPreTrtC
WIPreTrtH<-as.numeric(subset(PlotsLive, fdate==30506 & Plot=="H")$WoodyIncrement)
WIPreTrtC<-as.numeric(subset(PlotsLive, fdate==30506 & Plot=="C")$WoodyIncrement)
WIPreTrtCorr<-WIPreTrtH/WIPreTrtC
PGPreTrtH<-as.numeric(subset(PlotsLive, fdate==30506 & Plot=="H")$PctGrowth)
PGPreTrtC<-as.numeric(subset(PlotsLive, fdate==30506 & Plot=="C")$PctGrowth)
PGPreTrtCorr<-PGPreTrtH/PGPreTrtC

#Calculates pretreatment corrected values for the control plot.
PlotsCarbon$LiveWoodyBiomassPTCorr<-with(PlotsCarbon, ifelse(Plot=="C",LiveWoodyBiomass*BMPreTrtCorr,LiveWoodyBiomass))
PlotsCarbon$WoodyIncrementPTCorr<-with(PlotsCarbon, ifelse(Plot=="C",WoodyIncrement*WIPreTrtCorr,WoodyIncrement))

###Final Scaling and Plot Datafile-------------
#Converts units in the biomass columns from kg biomass/plot to kg carbon/ha. Then converts fdates into Year Names. From this point foward, it will be easier to work in excel. 
#(100/18) expands to (10000/900)*(1/2); the first term converts from /plot to /ha, the second from biomass to carbon.
PlotsCarbon$LiveBM.kg.ha<-PlotsCarbon$LiveWoodyBiomassPTCorr*(100/18)
PlotsCarbon$DeadBM.kg.ha<-PlotsCarbon$DeadPool*(100/18)
PlotsCarbon$WoodyIncrement.kg.ha<-PlotsCarbon$WoodyIncrementPTCorr*(100/18)
PlotsCarbon$Year<-ifelse(((PlotsCarbon$Plot=="C") | (PlotsCarbon$Plot=="H")), YearlyNames[match(PlotsCarbon$fdate,YearlyDates)], SCYearlyNames[match(PlotsCarbon$fdate,SCYearlyDates)])
PlotsCarbon$TotalStoredCarbon<-with(PlotsCarbon,LiveBM.kg.ha+DeadBM.kg.ha)   

write.csv(PlotsCarbon, "R Output Files/PlotsCarbon.csv", row.names=F)

###Individual Trees Datafile----------------
#Begins creating a dataframe mimicing the old "Final" SAS worksheet, which has proven very useful for data explorations. This gives you woody biomass, woody increment, and percent growth for every tree (except Buffer zone trees) at every yearly measurement date.
AllTrees<-reshape(YearlyDendro, v.names=c("fWoodyBiomass","WoodyIncrement","PctGrowth"), timevar="Year", idvar = "Tree", direction = "wide", drop = "fdate", sep=".")

AllDeadTrees<-reshape(subset(YearlyDendro, is.na(DeathDate)==F), v.names=c("fWoodyBiomass","WoodyIncrement","PctGrowth"), timevar="Year", idvar = "Tree", direction = "wide", drop = "fdate", sep=".")
AllDeadTrees$DeathYear<-YearlyNames[findInterval(AllDeadTrees$DeathDate,YearlyDates)+1]

#Reorders the columns to a layout closer to what you want to work with. This will need to be updated each year. 
#The names() function below is helpful for this.
names(AllTrees)
ColNames<-c("Plot","Tree", "Species", "DeathDate","fWoodyBiomass.InitialBM","fWoodyBiomass.PreTrt", "fWoodyBiomass.Year 1", "fWoodyBiomass.Year 2", "fWoodyBiomass.Year 3", "fWoodyBiomass.Year 4", "fWoodyBiomass.Year 5", "fWoodyBiomass.Year 6", "fWoodyBiomass.Year 7", "fWoodyBiomass.Year 8", "fWoodyBiomass.Year 9", "fWoodyBiomass.Year 10", "fWoodyBiomass.Year 11","WoodyIncrement.PreTrt", "WoodyIncrement.Year 1", "WoodyIncrement.Year 2","WoodyIncrement.Year 3","WoodyIncrement.Year 4","WoodyIncrement.Year 5","WoodyIncrement.Year 6","WoodyIncrement.Year 7","WoodyIncrement.Year 8","WoodyIncrement.Year 9","WoodyIncrement.Year 10","WoodyIncrement.Year 11","PctGrowth.PreTrt", "PctGrowth.Year 1", "PctGrowth.Year 2", "PctGrowth.Year 3", "PctGrowth.Year 4", "PctGrowth.Year 5", "PctGrowth.Year 6", "PctGrowth.Year 7", "PctGrowth.Year 8", "PctGrowth.Year 9", "PctGrowth.Year 10", "PctGrowth.Year 11")
AllTrees<-AllTrees[,ColNames]
AllTrees$DeathYear<-YearlyNames[findInterval(AllTrees$DeathDate,YearlyDates)+1]
##names(AllDeadTrees) ...This dataframe isn't working properly.
##DeadColNames<-c("") ...This dataframe isn't working properly.
##AllDeadTrees<-AllDeadTrees[,DeadColNames] ...This dataframe isn't working properly.

write.csv(subset(AllTrees, Plot %in% c("C","H")),"R Output Files/AllTrees.csv", row.names=F)
###write.csv(AllDeadTrees, "R Output Files/AllDeadTrees.csv", row.names=F) ...This dataframe isn't working properly. If this comment is still here, I never got around to getting to the bottom of why.